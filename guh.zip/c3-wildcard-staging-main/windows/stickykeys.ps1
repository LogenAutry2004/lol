$hash = Get-FileHash (where.exe cmd)
echo $hash
$hash3 = Get-FileHash (where.exe powershell)
echo $hash3
gci -r C:\Windows\system32\ | % {
    $path = $_.FullName
    $hash2 = Get-FileHash $path 2>$null
    if (($hash.Hash -eq $hash2.Hash -and $hash.Path -ne $hash2.Path) -or ($hash3.Hash -eq $hash2.Hash -and $hash3.Path -ne $hash3.Path)) {
        Add-Content -Path $logpath -Value ("sticky keys caught:`t" + $path)
        takeown /f $path
        icacls $path /grant everyone:F
        mv $path ($path + '.bak')
    }
}
Set-GPRegistryValue -Name "Default Domain Policy" -Key "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Accessibility" -ValueName "StickyKeys" -Type DWORD -Value 0
