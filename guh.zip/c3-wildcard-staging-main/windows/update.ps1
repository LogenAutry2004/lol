choco list --include-programs > C:\Users\programs.txt
[string[]]$programs = Get-Content -Path "C:\Users\programs.txt" | ForEach-Object { $_.Trim() }

$programMapping = @{
    "*Notepad++*"       = "notepadplusplus"
    "*Google Chrome*"   = "googlechrome"
    "*Acrobat*"         = "adobereader"
    "*GIMP*"            = "gimp"
    "*irfanview*"       = "irfanview"
    "*peazip*"          = "peazip"
    "*vlc*"             = "vlc"
    "*MobaXterm*"       = "mobaxterm"
    "*7zip*"            = "7zip"
    "*thunderbird*"     = "thunderbird"
    "*PuTTY*"           = "putty"
    "*Firefox*"         = "firefox"
    "*Opera*"           = "opera"
    "*KeePass*"         = "keepass"
    "*WinRAR*"          = "winrar"
    "*FileZilla Server*"= "filezilla.server"
    "*FileZilla*"       = "filezilla"
    "*LMMS*"            = "lmms"
    "*Java*"            = "javaruntime"
    "*Visual Studio Code*"            = "vscode"
    "*jEdit*"           = "jedit"
    "*Krita*"           = "krita"
    "*Internet Explorer*" = "ie11"
    "*Edge*" = "microsoft-edge"
}

foreach ($program in $programs) {
    foreach ($pattern in $programMapping.Keys) {
        if ($program -like $pattern) {
            $package = $programMapping[$pattern]
            choco upgrade $package -y --ignore-checksum
            break
        }
    }
}
