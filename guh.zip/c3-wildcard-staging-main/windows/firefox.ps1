
# Create registry path for Firefox policies
New-Item -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" -Force | Out-Null

# Enable Firefox Pop-up blocker
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" `
    -Name "PopupBlocking" -Value 1 -Type DWord

# Block dangerous downloads & deceptive content
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" `
    -Name "BlockAboutConfig" -Value 1 -Type DWord
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" `
    -Name "EnableTrackingProtection" -Value 1 -Type DWord
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" `
    -Name "BlockDangerousDownloads" -Value 1 -Type DWord

# Warn about unwanted and uncommon software
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" `
    -Name "BlockUncommonUnwanted" -Value 1 -Type DWord

# Enforce Add-on Signature Requirement
New-Item -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Extensions" -Force | Out-Null
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Extensions" `
    -Name "InstallAddonsPermission" -Value 0 -Type DWord
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox\Extensions" `
    -Name "ExtensionUpdate" -Value 0 -Type DWord

# Enforce HTTPS-Only mode in Firefox
Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Mozilla\Firefox" `
    -Name "HTTPSOnlyMode" -Value "always" -Type String