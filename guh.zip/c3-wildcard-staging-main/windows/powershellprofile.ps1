# Requires running as an Administrator.
# Get all directories in C:\Users excluding default and public folders
$UserFolders = Get-ChildItem -Path "C:\Users" -Directory | Where-Object {
    $_.Name -notmatch "^(Default|Public|All Users|Default User)$"
}

foreach ($user in $UserFolders) {
    $userProfilePath = $user.FullName

    # Define the known profile file paths for each user:
    # - Windows PowerShell profile (commonly located at Documents\WindowsPowerShell\profile.ps1)
    $wpProfilePath = Join-Path -Path $userProfilePath -ChildPath "Documents\WindowsPowerShell\profile.ps1"
    # - PowerShell Core profile (commonly located at Documents\PowerShell\profile.ps1)
    $psCoreProfilePath = Join-Path -Path $userProfilePath -ChildPath "Documents\PowerShell\profile.ps1"

    # Remove Windows PowerShell profile if it exists
    try {
        if (Test-Path $wpProfilePath) {
            Remove-Item -Path $wpProfilePath -Force
            Write-Output "Removed Windows PowerShell profile for user: $($user.Name)"
        }
    }
    catch {
        Write-Output "Error removing Windows PowerShell profile for user: $($user.Name): $_"
    }

    # Remove PowerShell Core profile if it exists
    try {
        if (Test-Path $psCoreProfilePath) {
            Remove-Item -Path $psCoreProfilePath -Force
            Write-Output "Removed PowerShell Core profile for user: $($user.Name)"
        }
    }
    catch {
        Write-Output "Error removing PowerShell Core profile for user: $($user.Name): $_"
    }
}
