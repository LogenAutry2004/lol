$filePath = Split-Path $MyInvocation.MyCommand.Path -Parent 
[string[]]$users = Get-Content -Path "$filePath\users.txt" | ForEach-Object { $_.Trim() }
[string[]]$admins = Get-Content -Path "$filePath\admins.txt" | ForEach-Object { $_.Trim() }

Write-Host "DC Strats"

# Aliases
function all { Get-AdUser -Filter * }
function notme { Get-AdUser -Filter * | Where-Object { $_.Name -ne $env:USERNAME } }

# Permissions
all | Set-ADObject -ProtectedFromAccidentalDeletion $false

# Enable Accounts (excluding krbtgt)
all | Where-Object Name -ne "krbtgt" | Enable-AdAccount

# Check if the "Cyber" account exists before processing the Administrator account
if (-not (Get-LocalUser -Name "Cyber" -ErrorAction SilentlyContinue)) {
    # Disable the Administrator account (using AD cmdlet if applicable)
    Disable-AdAccount -Identity Administrator
    # Rename Administrator to Cyber
    Rename-LocalUser -Name Administrator -NewName Cyber
    Write-Host "Administrator account disabled and renamed to Cyber."
} else {
    Write-Host "'Cyber' account exists. Skipping Administrator steps."
}

# Check if the "Patriot" account exists before processing the Guest account
if (-not (Get-LocalUser -Name "Patriot" -ErrorAction SilentlyContinue)) {
    # Disable the Guest account (using AD cmdlet if applicable)
    Disable-AdAccount -Identity Guest
    # Rename Guest to Patriot
    Rename-LocalUser -Name Guest -NewName Patriot
    Write-Host "Guest account disabled and renamed to Patriot."
} else {
    Write-Host "'Patriot' account exists. Skipping Guest steps."
}

# Set Password for all accounts
all | Set-AdAccountPassword -Reset -NewPassword ((ConvertTo-SecureString "Password123!@#" -AsPlainText -Force))

# List Rogue Accounts (accounts NOT in users.txt or admins.txt)
# Retrieve the rogue user accounts
$rogueUsers = all | Where-Object { 
    $_.SamAccountName -notin (($users) + ($admins) + "Cyber" + "Patriot" + "krbtgt")
}

if ($rogueUsers.Count -eq 0) {
    Write-Host "No rogue accounts found."
} else {
    Write-Host "Rogue Accounts (NOT IN README - DELETE!):"
    $rogueUsers | ForEach-Object {
        Write-Host $_.SamAccountName
    }

    # Prompt for deletion confirmation
    $confirmation = Read-Host "Do you want to delete these accounts? (Y/N)"
    if ($confirmation -eq "Y") {
        $rogueUsers | ForEach-Object {
            Remove-ADUser -Identity $_.SamAccountName -Confirm:$false
            Write-Host "Deleted account: $($_.SamAccountName)"
        }
    } else {
        Write-Host "No accounts deleted."
    }
}

# Create Missing Accounts (accounts IN README but not in AD)
Write-Host "Missing Accounts (IN README - CREATE!):"
$missing = (($users) + ($admins)) | Where-Object { $_ -notin (all | Select-Object -ExpandProperty SamAccountName) }

if ($missing.Count -eq 0) {
    Write-Host "All accounts 'account'ed for"
} else {
    Write-Host "Missing Accounts (IN README - CREATE!):"
    $missing | ForEach-Object {
        Write-Host $_
    }

    # Prompt for user creation confirmation
    $confirmation2 = (Read-Host "Do you want to create these accounts? (Y/N)").ToUpper()
    if ($confirmation2 -eq "Y") {
        $missing | ForEach-Object {
            New-ADUser -SamAccountName $_ -Name $_ `
                -GivenName $_ -DisplayName $_ `
                -AccountPassword (ConvertTo-SecureString "YourPasswordHere" -AsPlainText -Force) `
                -Enabled $true
            Write-Host "Created account: $_"
        }
    } else {
        Write-Host "No accounts created."
    }
}

# Remove Permitted, but Non-Admin Users from Admin Groups
$usersToRemove = Get-AdGroup -Filter "Name -like '*admin*'" | ForEach-Object {
    $groupName = $_.Name

    Get-AdGroupMember -Identity $groupName | Where-Object {
        # Exclude accounts in $admins, any account named "Cyber", and if in the "Administrators" group,
        # skip members with SamAccountName "Domain Admins" or "Enterprise Admins"
        ($admins -notcontains $_.SamAccountName) -and
        ($_.SamAccountName -ne 'Cyber') -and
        !($groupName -eq 'Administrators' -and ($_.SamAccountName -in @('Domain Admins', 'Enterprise Admins')))
    } | Select-Object @{Name = 'Group'; Expression = { $groupName }}, SamAccountName
}

if ($usersToRemove.Count -eq 0) {
    Write-Host "No non-admin users found in admin groups"
}
else {
    Write-Host "Permitted User(s), but NOT supposed to be admin(s):"
    $usersToRemove | Format-Table -AutoSize

    $response = Read-Host "Do you want to remove these users from the groups? (Y/N)"
    if ($response.ToUpper() -eq "Y") {
        foreach ($user in $usersToRemove) {
            Remove-AdGroupMember -Identity $user.Group -Members $user.SamAccountName -Confirm:$false
            Write-Host "Removed $($user.SamAccountName) from $($user.Group)"
        }
    }
}

# User should be Admin
Write-Host "Making users who should be admins admins..."
$admins | Where-Object { $_ -notin (Get-AdGroupMember "Domain Admins" | Select-Object -ExpandProperty SamAccountName) } | % { Add-ADGroupMember -Identity "Domain Admins" -Members $_ }
$admins | Where-Object { $_ -notin (Get-AdGroupMember "Enterprise Admins" | Select-Object -ExpandProperty SamAccountName) } | % { Add-ADGroupMember  -Identity "Enterprise Admins" -Members $_ }
$admins | Where-Object { $_ -notin (Get-AdGroupMember "Administrators" | Select-Object -ExpandProperty SamAccountName) } | % {Add-ADGroupMember  -Identity "Administrators" -Members $_ }

# DACL permissions
Start-Process powershell.exe -ArgumentList "-ExecutionPolicy Bypass -File .\resetdacl.ps1"

# Account Attributes
notme | Set-ADUser -PasswordNeverExpires $false
notme | Set-ADUser -ChangePasswordAtLogon $true
all | Set-ADUser -AllowReversiblePasswordEncryption $false
all | Set-ADUser -CannotChangePassword $false
all | Set-ADUser -Clear info,description,comment,notes
all | Set-ADUser -AccountNotDelegated $true
all | Set-ADAccountControl -UseDESKeyOnly $false
all | Set-ADAccountControl -DoesNotRequirePreAuth $false
all | Unlock-ADAccount

# Prevent "managed by" groups
Get-ADGroup -Filter * | Set-ADGroup -Clear ManagedBy

# Harrison cooking up
Get-AdUser -Filter "Name -notlike 'krbtgt'" | ForEach-Object { 
    Set-ADUser $_ -Replace @{UserAccountControl=($_.UserAccountControl -band (-bnot 128))} 
}

# NTDS.dit Permissions
icacls "C:\Windows\NTDS\ntds.dit" /reset

# Clear LostAndFound
Get-ADObject -SearchBase ("CN=LostAndFound," + (Get-ADDomain)) -SearchScope OneLevel -Filter * | Remove-ADObject -Confirm:$false

# Clear computer delegations
Get-ADComputer -Filter * -Properties msDS-AllowedToDelegateTo | ForEach-Object {
    Set-ADComputer $_ -Clear msDS-AllowedToDelegateTo -TrustedForDelegation $false
}

# "Anonymous LDAP bind disabled" on Mushroom practice image
$RootDSE = Get-ADRootDSE
$ObjectPath = 'CN=Directory Service,CN=Windows NT,CN=Services,{0}' -f $RootDSE.ConfigurationNamingContext
Set-ADObject -Identity $ObjectPath -Replace @{ 'msDS-Other-Settings' = 'DenyUnauthenticatedBind=1' }

$RootDSE = Get-ADRootDSE
$ObjectPath = 'CN=Directory Service,CN=Windows NT,CN=Services,{0}' -f $RootDSE.ConfigurationNamingContext
Set-ADObject -Identity $ObjectPath -Replace @{ 'dsHeuristics' = '0000000' }

Set-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" -Name "LDAPInterfaceFlags" -Value 2