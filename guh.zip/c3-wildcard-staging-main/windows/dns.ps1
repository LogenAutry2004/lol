dnscmd /config /enablednssec 1
dnscmd /config /retrieveroottrustanchors
dnscmd /config /enableglobalqueryblocklist 1
set-dnsserverdiagnostics -eventloglevel 3
Set-DnsServerDiagnostics -EnableLoggingForPluginDllEvent $true
Set-DnsServerRRL -Mode Enable -Force
Set-DnsServerResponseRateLimiting -ResetToDefault -Force
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters" -Name MaximumUdpPacketSize -Type DWord -Value 0x4C5 -Force
Set-DnsServerCache -PollutionProtection $true

# SIGRed workaround
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\DNS\Parameters" /v TcpReceivePacketSize /t REG_DWORD /d 0xFF00 /f 

# Secure DNS cache against pollution
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters" -Name "SecureResponses" -Value 1 -Type DWord

# Retrieve all DNS zones using Get-DnsServerZone
$zones = Get-DnsServerZone

# Loop through each zone and execute the reset command
foreach ($zone in $zones) {
    $zoneName = $zone.ZoneName
    Write-Host "Resetting secondaries for zone: $zoneName"
    try {
        dnscmd /ZoneResetSecondaries $zoneName /NoXfr
        set-dnsserverzone -name $zoneName -dynamicupdate none
        Write-Host "Successfully reset secondaries for $zoneName"
    }
    catch {
        Write-Warning "Error resetting secondaries for $zoneName : $_"
    }
}

# https://persistence-info.github.io/Data/serverlevelplugindll.html
$regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\DNS\Parameters"
$propertyName = "ServerLevelPluginDll"
$prop = Get-ItemProperty -Path $regPath -Name $propertyName -ErrorAction SilentlyContinue

if ($prop -and $prop.$propertyName) {
    $dllPath = $prop.$propertyName
    Write-Output "Found registry property value: $dllPath"
    if (Test-Path $dllPath) {
        Write-Output "File exists. Taking ownership and modifying permissions..."
        takeown.exe /f $dllPath
        icacls $dllPath /grant administrators:F
        $fileName = Split-Path $dllPath -Leaf
        $destination = "C:\$fileName.bak"
        Move-Item -Path $dllPath -Destination $destination
        Remove-ItemProperty -Path $regPath -Name $propertyName
        
        Write-Output "Operation complete."
    }
    else {
        Write-Output "File not found at $dllPath."
    }
}
else {
    Write-Output "Registry property '$propertyName' is not set."
}

net stop dns 
net start dns