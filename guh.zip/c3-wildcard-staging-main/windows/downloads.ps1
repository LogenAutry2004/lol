[Net.ServicePointManager]::SecurityProtocol = "Tls, Tls11, Tls12, Ssl3"

choco install everything --ignore-checksums -y
choco install es --ignore-checksums -y
powershell -executionpolicy bypass .\everything.ps1

choco install ProcExp --ignore-checksums -y
choco install ProcMon --ignore-checksums -y
choco install AutoRuns --ignore-checksums -y
choco install TcpView --ignore-checksums -y
choco install Streams --ignore-checksums -y
choco install RegDelNull --ignore-checksums -y

choco install malwarebytes --ignore-checksums -y