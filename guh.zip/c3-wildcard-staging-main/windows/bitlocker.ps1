# Import BitLocker module
Import-Module BitLocker

# Get all volumes that are not yet fully encrypted
$volumes = Get-BitLockerVolume | Where-Object {
    $_.EncryptionPercentage -lt 100 -and $_.VolumeType -ne 'Unknown'
}

foreach ($volume in $volumes) {
    $drive = $volume.MountPoint
    Write-Output "Enabling BitLocker on drive $drive..."

    # Skip drives that are already protected
    if ($volume.ProtectionStatus -eq 'On') {
        Write-Output "Drive $drive is already protected. Skipping..."
        continue
    }

    try {
        # Add TPM protector and enable encryption
        Enable-BitLocker -MountPoint $drive `
                         -EncryptionMethod XtsAes256 `
                         -UsedSpaceOnly `
                         -TpmProtector `
                         -ErrorAction Stop

        Write-Output "BitLocker enabled on drive $drive."
    }
    catch {
        Write-Error "Failed to enable BitLocker on drive $drive: $_"
    }
}