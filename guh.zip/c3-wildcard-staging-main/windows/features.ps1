$alwaysNo = @(
    "TelnetClient",
    "SMB1Protocol",
    "MicrosoftWindowsPowershellV2"
)

foreach ($feature in $alwaysNo) {
    Disable-WindowsOptionalFeature -Online -NoRestart -FeatureName $feature
}


$sometimesNo = @(
    "IIS-WebServerRole"
)

foreach ($feature in $sometimesNo) {
    $featureStatus = Get-WindowsOptionalFeature -Online -FeatureName $feature -ErrorAction SilentlyContinue

    if ($featureStatus.State -eq 'Enabled') {
        $response = Read-Host "Feature '$feature' is installed. Do you want to remove it? (y/n)"
        if ($response -match '^(y|yes)$') {
            Disable-WindowsOptionalFeature -Online -NoRestart -FeatureName $feature
            Write-Host "Feature '$feature' has been disabled."
        } else {
            Write-Host "Skipped disabling '$feature'."
        }
    } else {
        Write-Host "Feature '$feature' is not installed or not applicable."
    }
}


# Define the expected features
$expectedFeatures = @(
    "AD-Domain-Services"
    "DNS"
    "FileAndStorage-Services"
    "File-Services"
    "FS-FileServer"
    "Storage-Services"
    "NET-Framework-45-Features"
    "NET-Framework-45-Core"
    "NET-WCF-Services45"
    "GPMC"
    "Windows-Defender"
    "RSAT"
    "RSAT-Role-Tools"
    "RSAT-AD-Tools"
    "RSAT-AD-PowerShell"
    "RSAT-ADDS"
    "RSAT-AD-AdminCenter"
    "RSAT-ADDS-Tools"
    "RSAT-DNS-Server"
    "System-DataArchiver"
    "PowerShellRoot"
    "PowerShell"
    "WoW64-Support"
    "XPS-Viewer"
)

# Get all installed features
$installedFeatures = Get-WindowsFeature | Where-Object { $_.Installed } | Select-Object -ExpandProperty Name

# Compare and list extras
$extraInstalled = $installedFeatures | Where-Object { $_ -notin $expectedFeatures }

# Output
Write-Host "------------ Other non-default ---------------"
$extraInstalled
pause
