# Make sure services restart on failure
Get-Service | ForEach-Object {
    sc.exe failure $_.Name reset=10 actions=restart/10000/restart/10000/restart/10000 > $null 2>&1
}

$alwaysNo = @(
    "fax",
    "tlntsvr",
    "isns",
    "multipointservice",
    "remoteregistry",
    "NetTcpPortSharing",
    "rasman",
    "stcpip",
    "smtpsvc",
    "snmptrap",
    "snmp",
    "telnet",
    "ssdpsrv",
    "rpclocator",
    "riplistener",
    "simpletcp",
    "xblauthmanager",
    "upnphost",
    "lpdsvc",
    "spooler",
    "winrm",
    "semgrsvc",
    "webclient",
    "tapisrv",
    "simptcp",
    "xbox*",
    "xbl*"
)
$sometimesNot = @(
    "ftpsvc",
    "MSFTPSVC",
    "mysql",
    "dns",
    "sshd",
    "W3SVC"
)
$alwaysYes = @(
    "wuauserv",
    "EventLog",
    "MpsSvc",
    "Adobe Acrobat Update Service",
    "BDESVC"
)

$default = @(
    "AJRouter","ALG","AppIDSvc","Appinfo","AppMgmt","AppReadiness","AppVClient","AppXSvc","AudioEndpointBuilder",
    "Audiosrv","AxInstSV","BFE","BITS","BrokerInfrastructure","bthserv","camsvc","CDPSvc","CertPropSvc","ClipSVC",
    "cloudbase-init","COMSysApp","CoreMessagingRegistrar","CryptSvc","CscService","DcomLaunch","defragsvc",
    "DeviceAssociationService","DeviceInstall","DevQueryBroker","Dhcp","diagnosticshub.standardcollector.service",
    "DiagTrack","DispBrokerDesktopSvc","DmEnrollmentSvc","dmwappushservice","Dnscache","DoSvc","dot3svc","DPS",
    "DsmSvc","DsSvc","EapHost","edgeupdate","edgeupdatem","EFS","embeddedmode","EntAppSvc","EventLog","EventSystem",
    "fdPHost","FDResPub","FontCache","FrameServer","FrameServerMonitor","gpsvc","GraphicsPerfSvc","hidserv","HvHost",
    "IKEEXT","InstallService","iphlpsvc","KeyIso","KPSSVC","KtmRm","LanmanServer","LanmanWorkstation","lfsvc",
    "LicenseManager","lltdsvc","lmhosts","LSM","MapsBroker","McpManagementService","MicrosoftEdgeElevationService",
    "mpssvc","MSDTC","MSiSCSI","msiserver","NcaSvc","NcbService","Netlogon","Netman","netprofm","NetSetupSvc",
    "NetTcpPortSharing","NgcCtnrSvc","NgcSvc","NlaSvc","nsi","PcaSvc","PerfHost","pla","PlugPlay","PolicyAgent",
    "Power","PrintNotify","ProfSvc","PushToInstall","QEMU Guest Agent VSS Provider","QEMU-GA","QWAVE","RasAuto",
    "RasMan","RemoteAccess","RemoteRegistry","RmSvc","RpcEptMapper","RpcLocator","RpcSs","RSoPProv","sacsvr",
    "SamSs","SCardSvr","ScDeviceEnum","Schedule","SCPolicySvc","seclogon","SecurityHealthService","SEMgrSvc",
    "SENS","Sense","SensorDataService","SensorService","SensrSvc","SessionEnv","SgrmBroker","SharedAccess",
    "ShellHWDetection","shpamsvc","smphost","SNMPTRAP","Spooler","sppsvc","SSDPSRV","ssh-agent","SstpSvc",
    "StateRepository","StiSvc","StorSvc","svsvc","swprv","SysMain","SystemEventsBroker","TabletInputService",
    "tapisrv","TermService","Themes","TieringEngineService","TimeBrokerSvc","TokenBroker","TrkWks","TrustedInstaller",
    "tzautoupdate","UALSVC","UevAgentService","UmRdpService","upnphost","UserManager","UsoSvc","VaultSvc","vds",
    "vmicguestinterface","vmicheartbeat","vmickvpexchange","vmicshutdown","vmictimesync","vmicvmsession","vmicvss",
    "VSS","W32Time","WaaSMedicSvc","WalletService","WarpJITSvc","WbioSrvc","Wcmsvc","WdiServiceHost",
    "WdiSystemHost","WdNisSvc","Wecsvc","WEPHOSTSVC","wercplsupport","WerSvc","WiaRpc","WinDefend",
    "WinHttpAutoProxySvc","Winmgmt","WinRM","wisvc","wlidsvc","wmiApSrv","WMPNetworkSvc","WPDBusEnum",
    "WpnService","WSearch","wuauserv",
    "CaptureService_*","cbdhsvc_*","CDPUserSvc_*","ConsentUxUserSvc_*","CredentialEnrollmentManagerUserSvc_*",
    "DeviceAssociationBrokerSvc_*","DevicePickerUserSvc_*","DevicesFlowUserSvc_*","PimIndexMaintenanceSvc_*",
    "PrintWorkflowUserSvc_*","UdkUserSvc_*","UnistoreSvc_*","UserDataSvc_*","WpnUserService_*",
    "vm3dservice","VMTools","vmvss","CCSClient",
    # whitelist more stuff from north korea practice image
    "BluetoothUserService_*", "BTAGService", "BthAvctpSvc", "CloudBackupRestoreSvc_*",
    "CSSClient", "dcsvc", "DisplayEnhancementService", "GameInputSvc", "InventorySvc",
    "LxpSvc", "NaturalAuthentication", "NPSMSvc_*", "OneSyncSvc_*", "P9RdrService_*", "PrintDeviceConfigurationService",
    "PrintScanBrokerService", "refsdedupsvc", "TextInputManagementService", "VGAuthService",
    "vmicrdv", "wcncsvc", "WFDSConMgrSvc", "WlanSvc", "WManSvc", "workfolderssvc", "WSAIFabricSvc", "XblAuthManager"
}
$roleMapping = @{
    "IIS"   = "W3SVC|WAS|IISADMIN"
    "ADDS"  = "NTDS|ADWS|ActiveDirectory|NTDS|ADWS|DFS|DFSR|DNS|DsRoleSvc|NtFrs|Kdc|KdsSvc|IsmServ"
    "DNS"   = "DNS"
    "ADCS"  = "CertSvc|Certificate"
}

Get-Service | ForEach-Object {
    $service = $_
    $isDefault = $false

    foreach ($pattern in $default) {
        # Convert wildcard patterns (if any) into proper regex anchors.
        $regexPattern = "^" + ($pattern -replace "\*", ".*") + "$"
        if ($service.Name -match $regexPattern) {
            $isDefault = $true
            break
        }
    }

    if (-not $isDefault) {
        # Retrieve extended properties (including the startup type) via CIM.
        $serviceCim = Get-CimInstance -ClassName Win32_Service -Filter "Name='$($service.Name)'"
        $startupType = $serviceCim.StartMode
        $state = $service.Status

        # Determine associated roles based on service name or display name.
        $associatedRoles = @()
        foreach ($role in $roleMapping.Keys) {
            $pattern = $roleMapping[$role]
            if ($service.Name -match $pattern -or $service.DisplayName -match $pattern) {
                $associatedRoles += $role
            }
        }

        if ($associatedRoles.Count -gt 0) {
            $roleInfo = "associated with role(s): " + ($associatedRoles -join ", ")
        }
        else {
            $roleInfo = "with no associated role"
        }

        Write-Output "Non-default service found $($service.Name) $($service.DisplayName) with startup $startupType, state $state, $roleInfo"
    }
}

# Disable / stop stuff
foreach ($pattern in $alwaysNo) {
    Get-Service -Name $pattern -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.Status -eq 'Running') {
            Stop-Service -Name $_.Name -Force
            Write-Output "Stopped $($_.Name)"
        }
        if ($_.StartMode -ne 'Disabled') {
            Set-Service -Name $_.Name -StartupType Disabled
            Write-Output "Disabled $($_.Name)"
        }
    }
}

# Enable / start stuff
foreach ($pattern in $alwaysYes) {
    Get-Service -Name $pattern -ErrorAction SilentlyContinue | ForEach-Object {
        if ($_.StartType -eq 'Disabled') {
            Set-Service -Name $_.Name -StartupType Automatic
            Write-Output "Enabled $($_.Name)"
        }
        if ($_.Status -ne 'Running') {
            Start-Service -Name $_.Name
            Write-Output "Started $($_.Name)"
        }
    }
}

# Could be a critical service, inform the user
foreach ($pattern in $sometimesNot) {
    $service = Get-Service -Name $pattern -ErrorAction SilentlyContinue
    if ($service) {
        Write-Output "WARNING: Potentially unwanted service '$($service.Name)' has startup type '$($service.StartType)' and is currently '$($service.Status)'. This service may be critical."
        $userResponse = Read-Host "Do you want to disable and stop this service? (Y/N)"
        if ($userResponse -match '^(Y|y)$') {
            # Stop the service if it is currently running.
            if ($service.Status -eq 'Running') {
                try {
                    Stop-Service -Name $service.Name -Force -ErrorAction Stop
                    Write-Output "Service '$($service.Name)' has been stopped."
                }
                catch {
                    Write-Output "Error stopping service '$($service.Name)': $_"
                }
            }
            # Disable the service by setting its startup type to Disabled.
            try {
                Set-Service -Name $service.Name -StartupType Disabled -ErrorAction Stop
                Write-Output "Service '$($service.Name)' has been disabled."
            }
            catch {
                Write-Output "Error disabling service '$($service.Name)': $_"
            }
        }
        else {
            Write-Output "No changes made for service '$($service.Name)'."
        }
    }
    else {
        Write-Output "Service matching '$pattern' not found."
    }
}
