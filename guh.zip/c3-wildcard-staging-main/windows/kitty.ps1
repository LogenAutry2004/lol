
Import-Module "$Env:ProgramFiles\WindowsPowerShell\Modules\HardeningKitty\$Version\HardeningKitty.psm1"
Invoke-HardeningKitty -Mode HailMary -Log -Report -SkipRestorePoint -FileFindingList .\lists\finding_list_0x6d69636b_machine.csv
Invoke-HardeningKitty -Mode HailMary -Log -Report -SkipRestorePoint -FileFindingList .\lists\finding_list_0x6d69636b_user.csv
Invoke-HardeningKitty -Mode HailMary -Log -Report -SkipRestorePoint -FileFindingList .\lists\finding_list_msft_security_baseline_edge_128_machine.csv
Invoke-HardeningKitty -Mode HailMary -Log -Report -SkipRestorePoint -FileFindingList .\lists\finding_list_microsoft_windows_tls_future.csv
Invoke-HardeningKitty -Mode HailMary -Log -Report -SkipRestorePoint -FileFindingList  .\lists\finding_list_dod_windows_defender_antivirus_stig_v2r1.csv
Invoke-HardeningKitty -Mode HailMary -Log -Report -SkipRestorePoint -FileFindingList  .\lists\finding_list_dod_windows_firewall_stig_v1r7.csv