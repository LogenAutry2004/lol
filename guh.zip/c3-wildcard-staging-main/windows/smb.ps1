# Define the expected baseline for SMB shares and their permissions
$baseline = @{
    "ADMIN$" = @(
        @{ AccountName = "BUILTIN\Administrators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "BUILTIN\Backup Operators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "NT AUTHORITY\INTERACTIVE"; AccessControlType = "Allow"; AccessRight = "Full" }
    );
    "C$" = @(
        @{ AccountName = "BUILTIN\Administrators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "BUILTIN\Backup Operators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "NT AUTHORITY\INTERACTIVE"; AccessControlType = "Allow"; AccessRight = "Full" }
    );
    "IPC$" = @(
        @{ AccountName = "BUILTIN\Administrators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "BUILTIN\Backup Operators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "NT AUTHORITY\INTERACTIVE"; AccessControlType = "Allow"; AccessRight = "Full" }
    );
    "NETLOGON" = @(
        @{ AccountName = "Everyone"; AccessControlType = "Allow"; AccessRight = "Read" },
        @{ AccountName = "BUILTIN\Administrators"; AccessControlType = "Allow"; AccessRight = "Full" }
    );
    "SYSVOL" = @(
        @{ AccountName = "Everyone"; AccessControlType = "Allow"; AccessRight = "Read" },
        @{ AccountName = "BUILTIN\Administrators"; AccessControlType = "Allow"; AccessRight = "Full" },
        @{ AccountName = "NT AUTHORITY\Authenticated Users"; AccessControlType = "Allow"; AccessRight = "Full" }
    )
}

# Function to compare two permission lists
function Compare-PermissionLists {
    param(
        [array]$BaselineList,
        [array]$ActualList
    )
    $missing = @()
    $extra = @()

    # Identify baseline entries not found in the current configuration
    foreach ($perm in $BaselineList) {
        $found = $ActualList | Where-Object {
            $_.AccountName -eq $perm.AccountName -and
            $_.AccessControlType -eq $perm.AccessControlType -and
            $_.AccessRight -eq $perm.AccessRight
        }
        if (-not $found) {
            $missing += $perm
        }
    }
    # Identify entries in the current configuration that are not in the baseline
    foreach ($perm in $ActualList) {
        $found = $BaselineList | Where-Object {
            $_.AccountName -eq $perm.AccountName -and
            $_.AccessControlType -eq $perm.AccessControlType -and
            $_.AccessRight -eq $perm.AccessRight
        }
        if (-not $found) {
            $extra += $perm
        }
    }
    return @{Missing = $missing; Extra = $extra}
}

# Get current SMB shares
$currentShares = Get-SmbShare

# 1. Check for any shares that exist but are not in the baseline.
foreach ($share in $currentShares) {
    if (-not $baseline.ContainsKey($share.Name)) {
        $response = Read-Host "Share '$($share.Name)' is not in the baseline. Delete this share? (Y/N)"
        if ($response -match '^[Yy]') {
            Remove-SmbShare -Name $share.Name -Force
            Write-Output "Deleted share '$($share.Name)'."
        }
    }
}

# 2. For each baseline share, check for permission differences.
foreach ($shareName in $baseline.Keys) {
    $currentShare = $currentShares | Where-Object { $_.Name -eq $shareName }
    if ($currentShare) {
        $actualPerms = Get-SmbShareAccess -Name $shareName
        $diff = Compare-PermissionLists -BaselineList $baseline[$shareName] -ActualList $actualPerms

        if ($diff.Missing.Count -gt 0 -or $diff.Extra.Count -gt 0) {
            Write-Output "Permission differences detected for share '$shareName':"
            if ($diff.Missing.Count -gt 0) {
                Write-Output "Missing permissions (should be present):"
                $diff.Missing | Format-Table -AutoSize
            }
            if ($diff.Extra.Count -gt 0) {
                Write-Output "Extra permissions (should be removed):"
                $diff.Extra | Format-Table -AutoSize
            }
            $fix = Read-Host "Fix permissions for share '$shareName' to match baseline? (Y/N)"
            if ($fix -match '^[Yy]') {
                # Remove extra permissions
                foreach ($perm in $diff.Extra) {
                    Revoke-SmbShareAccess -Name $shareName -AccountName $perm.AccountName -Force
                    Write-Output "Removed extra permission for account $($perm.AccountName) on share '$shareName'."
                }
                # Add missing permissions
                foreach ($perm in $diff.Missing) {
                    Grant-SmbShareAccess -Name $shareName -AccountName $perm.AccountName -AccessRight $perm.AccessRight -Force
                    Write-Output "Added missing permission for account $($perm.AccountName) on share '$shareName'."
                }
            }
        }
        else {
            Write-Output "Permissions for share '$shareName' match the baseline."
        }
    }
    else {
        Write-Output "Baseline share '$shareName' does not exist on this system."
    }
}
