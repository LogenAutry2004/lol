$path = "C:\Users\quarantineMedia"
if (-not (Test-Path -Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
}
$regexes = @(
    # Video files
    ".3gp$",
    ".avi$",
    ".flv$",
    ".m4v$",
    ".mkv$",
    ".mov$",
    ".mp4$",
    ".mpeg$",
    ".mpg$",
    ".wmv$",
    ".webm$",
    ".rm$",
    ".rmvb$",
    ".vob$",
    ".ogv$",
    ".rec$",
    # Audio files
    ".aac$",
    ".aiff$",
    ".alac$",
    ".flac$",
    ".m4a$",
    ".mp3$",
    ".ogg$",
    ".opus$",
    ".wav$",
    ".wma$",
    ".ac3$",
    # Office suite files (Microsoft Office, OpenDocument, etc.)
    ".doc$",
    ".docx$",
    ".docm$",     # Word macro-enabled
    ".xls$",
    ".xlsx$",
    ".xlsm$",     # Excel macro-enabled
    ".ppt$",
    ".pptx$",
    ".pptm$",     # PowerPoint macro-enabled
    ".pot$",      # PowerPoint Template
    ".potx$",     # PowerPoint Template (Open XML)
    ".potm$",     # PowerPoint Template (macro-enabled)
    ".odt$",      # OpenDocument Text
    ".ods$",      # OpenDocument Spreadsheet
    ".odp$",      # OpenDocument Presentation
    ".rtf$",      # Rich Text Format — can carry embedded objects/macros
    # Documents
    ".pdf$",
    # Potentially malicious or suspicious files
    ".rdp$",
    ".rhost$" 
)

$file = "C:\Users\mediafiles.txt"
if (Test-Path $file) { Clear-Content $file }
else { New-Item -Path $file -ItemType File }

foreach ($regex in $regexes) {
    $mediaPaths = es.exe /a-d -r $regex
    foreach ($mediaPath in $mediaPaths) {
        if ($mediaPath -notcontains $path) {
            echo $mediaPath >> C:\Users\mediafiles.txt
        }
    }
}

cat C:\Users\mediafiles.txt | % { takeown /f $_; icacls $_ /grant "$($env:USERNAME):F"; mv $_ $path\ }

# find powershell histories
$powershellPath = "C:\Users\powershellHistories"
if (-not (Test-Path -Path $powershellPath)) {
    New-Item -ItemType Directory -Path $powershellPath | Out-Null
}
$historyPaths = es.exe /a-d "ConsoleHost_history.txt"
foreach ($historyPath in $historyPaths) {
    if ($historyPath -notlike "*$powershellPath*"){
        echo $historyPath >> C:\Users\powershellHistories.txt
    }
}
Get-Content C:\Users\powershellHistories.txt | ForEach-Object { 
    takeown /f $_
    icacls $_ /grant "$($env:USERNAME):F"
    $randName = [guid]::NewGuid().ToString() + ".txt"
    Copy-Item $_ -Destination (Join-Path $powershellPath $randName)
}

# find potential web shells
$path = "C:\Users\quarantineWeb"
if (-not (Test-Path -Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
}
$regexes = @(
    ".php$",
    ".phtml$",
    ".php5$",
    ".asp$",
    ".aspx$",
    ".asax$"
)
if (-not (Test-Path "C:\Users\wwwroot.zip")) {
    Compress-Archive -Path "C:\inteput\wwwroot\*" -DestinationPath "C:\Users\wwwroot.zip"
}
foreach ($regex in $regexes) {
    $mediaPaths = es.exe /a-d -r $regex
    foreach ($mediaPath in $mediaPaths) {
        if ($mediaPath -notcontains $path) {
            echo $mediaPath >> C:\Users\webfiles.txt
        }
    }
}
$extraPaths = es.exe /a-d -r "C:\inteput\wwwroot"
echo $extraPaths >> C:\Users\webfiles.txt
powershell .\webshell.ps1

## CLEAR RDP CACHES
# Define the quarantine folder path
$quarantineFolder = "C:\Users\quarantineRDPCache"

# Create the quarantine folder if it doesn't exist
if (-not (Test-Path -Path $quarantineFolder)) {
    New-Item -Path $quarantineFolder -ItemType Directory -Force | Out-Null
}

# Iterate through each user folder in C:\Users
Get-ChildItem -Path "C:\Users" -Directory | ForEach-Object {
    $userFolder = $_.FullName
    # Construct the expected RDP cache folder path
    $rdpCachePath = Join-Path -Path $userFolder -ChildPath "AppData\Local\Microsoft\Terminal Server Client\Cache"
    
    # Check if the RDP cache folder exists
    if (Test-Path -Path $rdpCachePath) {
        # Enumerate each file in the RDP cache folder (non-recursive)
        Get-ChildItem -Path $rdpCachePath -File | ForEach-Object {
            $filePath = $_.FullName
            Write-Host "Found RDP cache file: $filePath"
            # Move the file to the quarantine folder
            Move-Item -Path $filePath -Destination $quarantineFolder -Force
        }
    }
}

Write-Host "Finding evil executables..."
# find evil executables

$file = "C:\Users\evilFiles.txt"
if (Test-Path $file) { Clear-Content $file }
else { New-Item -Path $file -ItemType File }
foreach ($regex in $(cat evilfiles.txt)) {
    $thisEvil = es.exe /a-d -r $regex
    echo $thisEvil >> C:\Users\evilFiles.txt
}

Write-Host "Finding passwords..."
# find potential passwords on disk
$path = "C:\Users\quarantinePasswords"
if (-not (Test-Path -Path $path)) {
    New-Item -ItemType Directory -Path $path | Out-Null
}
$regexes = @(
    ".txt$",
    ".csv$",
    ".html$",
    ".htm$"
)

foreach ($regex in $regexes) {
    $passwordPaths = es.exe /a-d -r $regex
    foreach ($passwordPath in $passwordPaths) {
        if (($passwordPath -notcontains $path) -and ($passwordPath -notcontains "passwordsFromReadme.txt") -and ($passwordPath -notcontains "Recycle.Bin")) {
            echo $passwordPath >> C:\Users\passwordfiles.txt
        }
    }
}
if (-not [System.IO.File]::Exists("C:\Users\passwordsFromReadme.txt")){
    New-Item C:\Users\passwordsFromReadme.txt
}

Write-Host "Put this list of passwords from the readme in C:\Users\passwordsFromReadme.txt"
Start-Process notepad.exe C:\Users\passwordsFromReadme.txt
pause
powershell .\password.ps1 -PasswordsFile C:\Users\passwordsFromReadme.txt -FilesList C:\Users\passwordfiles.txt