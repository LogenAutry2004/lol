param (
    [Parameter(Mandatory = $true)]
    [string]$PasswordsFile,

    [Parameter(Mandatory = $true)]
    [string]$FilesList
)

# Output log file
$logFile = "password_hits.txt"
Remove-Item $logFile -ErrorAction SilentlyContinue

# Read inputs
$passwords = Get-Content $PasswordsFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
$files = Get-Content $FilesList | ForEach-Object { $_.Trim() } | Where-Object { Test-Path $_ }

$found = $false

foreach ($file in $files) {
    $content = Get-Content $file -Raw

    foreach ($password in $passwords) {
        if ($content -like "*$password*") {
            $found = $true
            $log = "Match found in ${file}: '$password'"
            Add-Content -Path $logFile -Value $log
        }
    }
}

if ($found) {
    Write-Host "`n[+]" -ForegroundColor Green -NoNewline
    Write-Host " Password matches were found and logged to $logFile"
} else {
    Write-Host "`n[-]" -ForegroundColor Red -NoNewline
    Write-Host " No passwords found in listed files."
}

