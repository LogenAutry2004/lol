$filePath = Split-Path $MyInvocation.MyCommand.Path -Parent 
[string[]]$users = Get-Content -Path "$filePath\users.txt" | ForEach-Object { $_.Trim() }
[string[]]$admins = Get-Content -Path "$filePath\admins.txt" | ForEach-Object { $_.Trim() }

# Enable all accounts    
Get-LocalUser | Enable-LocalUser

# Set Passwords
Get-LocalUser | % {net user $_.Name 'Password123!@#'}
Get-LocalUser | Where-Object Name -notlike $env:USERNAME | % {net user $_.Name /passwordchg:yes /passwordreq:yes /logonpasswordchg:yes /usercomment:" "}

# Disable + Rename Guest/Administrator

# Check if the "Cyber" account exists before processing the Administrator account
if (-not (Get-LocalUser -Name "Cyber" -ErrorAction SilentlyContinue)) {
	Disable-LocalUser Administrator
	Rename-LocalUser Administrator Cyber
	Write-Host "Administrator account disabled and renamed to Cyber."
} else {
    Write-Host "'Cyber' account exists. Skipping Administrator steps."
}

# Check if the "Patriot" account exists before processing the Guest account
if (-not (Get-LocalUser -Name "Patriot" -ErrorAction SilentlyContinue)) {
	Disable-LocalUser Guest
	Rename-LocalUser Guest Patriot
	Write-Host "Guest account disabled and renamed to Patriot."
} else {
    Write-Host "'Patriot' account exists. Skipping Guest steps."
}

# List Rogue Accounts (accounts NOT in users.txt or admins.txt)
# Retrieve the rogue user accounts
$rogueUsers = Get-LocalUser | Where-Object { 
    $_.Name -notin (($users) + ($admins) + "Cyber" + "Patriot")
}

if ($rogueUsers.Count -eq 0) {
    Write-Host "No rogue accounts found."
} else {
    Write-Host "Rogue Accounts (NOT IN README - DELETE!):"
    $rogueUsers | ForEach-Object {
        Write-Host $_.Name
    }

    # Prompt for deletion confirmation
    $confirmation = Read-Host "Do you want to delete these accounts? (Y/N)"
    if ($confirmation -eq "Y") {
        $rogueUsers | ForEach-Object {
            Remove-LocalUser -Name $_.Name -Confirm:$false
            Write-Host "Deleted account: $($_.Name)"
        }
    } else {
        Write-Host "No accounts deleted."
    }
}

# Create Missing Accounts (accounts IN README but not in AD)
$missing = (($users) + ($admins)) | Where-Object { $_ -notin (Get-LocalUser | Select-Object -ExpandProperty Name) }

if ($missing.Count -eq 0) {
    Write-Host "All accounts 'account'ed for"
} else {
    Write-Host "Missing Accounts (IN README - CREATE!):"
    $missing | ForEach-Object {
        Write-Host $_
    }

    # Prompt for user creation confirmation
    $confirmation = Read-Host "Do you want to create these accounts? (Y/N)"
    if ($confirmation -eq "Y") {
        $missing | ForEach-Object {
            New-LocalUser -Name $_ -Password (ConvertTo-SecureString "YourPasswordHere" -AsPlainText -Force)
            Write-Host "Created account: $($_)"
        }
    } else {
        Write-Host "No accounts created."
    }
}

# Retrieve current members of the Administrators group (suppress errors if group not found)
$adminGroupMembers = Get-LocalGroupMember -Group "Administrators" -ErrorAction SilentlyContinue

foreach ($admin in $admins) {
    # Check if the current admin is already in the Administrators group
    $isMember = $adminGroupMembers | Where-Object { $_.Name -eq $admin }
    
    if (-not $isMember) {
        # Prompt the user for confirmation
        $response = Read-Host "User '$admin' is not in the Administrators group. Do you want to add them? (Y/N)"
        
        if ($response.ToUpper() -eq "Y") {
            try {
                Add-LocalGroupMember -Group "Administrators" -Member $admin -ErrorAction Stop
                Write-Host "Successfully added '$admin' to the Administrators group."
            }
            catch {
                Write-Error "Failed to add '$admin': $_"
            }
        }
        else {
            Write-Host "Skipped adding '$admin'."
        }
    }
    else {
        Write-Host "'$admin' is already a member of the Administrators group."
    }
}


# Remove Permitted, but Non-Admin Users from Admin Groups
$usersToRemove = Get-LocalGroup | Where-Object Name -like '*admin*' | ForEach-Object {
    $groupName = $_.Name

    Get-LocalGroupMember $groupName | Where-Object {
        ($admins -notcontains $_.Name.Split("\")[1].Trim()) -and
        ("Cyber" -ne $_.Name.Split("\")[1].Trim())
    } | Select-Object @{Name = 'Group'; Expression = { $groupName }}, Name
}

if ($usersToRemove.Count -eq 0) {
    Write-Host "No non-admin users found in admin groups"
}
else {
    Write-Host "Permitted User(s), but NOT supposed to be admin(s):"
    $usersToRemove | Format-Table -AutoSize

    $response = Read-Host "Do you want to remove these users from the groups? (Y/N)"
    if ($response.ToUpper() -eq "Y") {
        foreach ($user in $usersToRemove) {
            Remove-LocalGroupMember $user.Group $user.Name -Confirm:$false
            Write-Host "Removed $($user.Name) from $($user.Group)"
        }
    }
}

# Account Security
Get-LocalUser | Where-Object Name -notlike $env:USERNAME | Set-LocalUser -PasswordNeverExpires $false -UserMayChangePassword $true