$filePath = Split-Path $MyInvocation.MyCommand.Path -Parent 
if (-not [System.IO.File]::Exists($filePath+"\users.txt")){
    New-Item $filePath/users.txt
}
if (-not [System.IO.File]::Exists($filePath+"\admins.txt")){
    New-Item $filePath/admins.txt
}

Write-Host "Put the list of users and admins from the ReadMe in their respective .txt files in the same folder this script is in."
Start-Process notepad.exe $filePath\users.txt
Start-Process notepad.exe $filePath\admins.txt
pause

[string[]]$users = Get-Content -Path "$filePath\users.txt" | ForEach-Object { $_.Trim() }
[string[]]$admins = Get-Content -Path "$filePath\admins.txt" | ForEach-Object { $_.Trim() }

Write-Host "USERS:" 
foreach ($user in $users){Write-Host $user}
Write-Host ""
Write-Host "ADMINS:"
foreach ($admin in $admins){Write-Host $admin}

Write-Host ""

Write-Host "Okay, there's the list this script grabbed from those files. If it's correct, hit enter to continue. If not, hit Ctrl+C to kill the script and start over."
pause