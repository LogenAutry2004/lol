# Define the destination folder and metadata file
$Destination = "C:\webshells"
if (!(Test-Path $Destination)) {
    New-Item -Path $Destination -ItemType Directory | Out-Null
}
$MetadataFile = Join-Path $Destination "metadata.txt"

# Define a list of suspicious patterns for PHP and ASPX webshells
$suspiciousPatterns = @(
    # PHP patterns
    "eval",
    "base64_decode",
    "gzinflate",
    "str_rot13",
    "assert",
    "system",
    "shell_exec",
    "passthru",
    "exec",
    "popen",
    "proc_open",
    "phpinfo"
    # ASPX patterns
    "Process",
    "System",
    "ExecuteNonQuery",
    "Page\.Load",
    "new\s+OleDbCommand",
    "Eval"
)

Write-Host "Reading file paths from C:\Users\webfiles.txt..."

# Read file paths from the list (assume all are valid)
$filePaths = Get-Content "C:\Users\webfiles.txt" | ForEach-Object { $_.Trim() }

foreach ($filePath in $filePaths) {
    Write-Host "Analyzing $filePath..."
    $isSuspicious = $false
    $content = $null

    try {
        $content = Get-Content $filePath -Raw

        foreach ($pattern in $suspiciousPatterns) {
            if ($content -match $pattern) {
                $isSuspicious = $true
                break
            }
        }
    } catch {
        Write-Warning "Error reading file: $filePath. Treating as suspicious."
        $isSuspicious = $true
    }

    if ($isSuspicious) {
        $file = Get-Item $filePath
        $destinationPath = Join-Path $Destination $file.Name

        if (Test-Path $destinationPath) {
            $timestamp = Get-Date -Format "yyyyMMddHHmmss"
            $destinationPath = Join-Path $Destination ("{0}_{1}{2}" -f [System.IO.Path]::GetFileNameWithoutExtension($file.Name), $timestamp, $file.Extension)
        }

        Write-Host "Suspicious file detected:`n   Original: $filePath`n   Moving to: $destinationPath"
        Move-Item -Path $filePath -Destination $destinationPath -Force

        $metadataEntry = "{0} - Moved file from: {1}" -f (Get-Date), $filePath
        Add-Content -Path $MetadataFile -Value $metadataEntry
    }
}

Write-Host "Scan complete. Please review the files in $Destination and check metadata.txt for original locations."
