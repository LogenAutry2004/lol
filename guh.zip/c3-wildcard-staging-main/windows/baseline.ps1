# Disable existing GPOs
Get-Gpo -All | % { $_.GpoStatus="AllSettingsDisabled"}

# === Auto-detect system role and apply correct baseline ===
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

# Detect system role
$computer = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem
$isDomainJoined = $computer.PartOfDomain
$role = $computer.DomainRole
$isDomainController = $role -eq 5

# Set baseline switches
$WSMember = $false
$WSNonDomainJoined = $false
$WSDomainController = $false

if ($isDomainController) {
    $WSDomainController = $true
} elseif ($isDomainJoined) {
    $WSMember = $true
} else {
    $WSNonDomainJoined = $true
}

# === Determine baseline folder ===
$baseline = ""
# For Windows Server 2016 or 2019, force the 22 baseline.
if ($os.Caption -match "Server" -and ($os.Caption -match "2016" -or $os.Caption -match "2019")) {
    $baseline = "DC22"
} elseif ($os.Caption -match "Server.*20(\d{2})") {
    $baseline = "DC$($Matches[1])"
} elseif ($os.Caption -match "Windows 11") {
    $build = [int]$os.BuildNumber
    switch ($build) {
        { $_ -ge 22621 -and $_ -lt 22631 } { $baseline = "WK11v22H2"; break }
        { $_ -ge 22631 -and $_ -lt 22635 } { $baseline = "WK11v23H2"; break }
        { $_ -ge 22635 }                  { $baseline = "WK11v24H2"; break }
        default                          { $baseline = "WK11" }
    }
} elseif ($os.Caption -match "Windows 10") {
    $baseline = "WK10v22H2"
}

if (-not $baseline) {
    Write-Error "Could not determine appropriate baseline folder."
    return
}

$baselinePath = Join-Path $scriptRoot $baseline
$scriptsPath = Join-Path $baselinePath "Scripts"
$toolsPath = Join-Path $scriptsPath "Tools"
$gpoPath = Join-Path $baselinePath "GPOs"
$templatesPath = Join-Path $baselinePath "Templates"
$configFilesPath = Join-Path $scriptsPath "ConfigFiles"

# === Import GUID-to-GPO-name mapping ===
$mapScriptPath = Join-Path $toolsPath "MapGuidsToGpoNames.ps1"

if (-not (Test-Path $mapScriptPath)) {
    Write-Error "Missing MapGuidsToGpoNames.ps1 at: $mapScriptPath"
    return
}

# Unblock the file if necessary
Unblock-File -Path $mapScriptPath

$GpoMap = & $mapScriptPath $gpoPath
$bMissingGPO = $false

function AddToCollection([System.Collections.Hashtable]$ht, [System.String]$GpoName) {
    $guid = $GpoMap[$GpoName]
    if ($null -eq $guid) {
        $Script:bMissingGPO = $true
        Write-Error "MISSING GPO: $GpoName"
    } else {
        $ht.Add($GpoName, $guid)
    }
}

# === Define GPO Names ===
$GPO_IE11_Computer       = "MSFT Internet Explorer 11 - Computer"
$GPO_IE11_User           = "MSFT Internet Explorer 11 - User"
$GPO_WS_DefenderAV       = "MSFT Windows Server 2022 - Defender Antivirus"
$GPO_WS_DC               = "MSFT Windows Server 2022 - Domain Controller"
$GPO_WS_DC_VBS           = "MSFT Windows Server 2022 - Domain Controller Virtualization Based Security"
$GPO_WS_DomainSec        = "MSFT Windows Server 2022 - Domain Security"
$GPO_WS_Member           = "MSFT Windows Server 2022 - Member Server"
$GPO_WS_CredentialGuard  = "MSFT Windows Server 2022 - Member Server Credential Guard"

# === Select GPOs ===
$GPOs = @{}
$baselineLabel = ""

if ($WSMember -or $WSNonDomainJoined) {
    if ($WSMember) {
        $baselineLabel = "Windows Server - domain-joined"
    } else {
        $baselineLabel = "Windows Server - non-domain-joined"
    }
    AddToCollection $GPOs $GPO_IE11_Computer
    AddToCollection $GPOs $GPO_IE11_User
    AddToCollection $GPOs $GPO_WS_DomainSec
    AddToCollection $GPOs $GPO_WS_DefenderAV
    AddToCollection $GPOs $GPO_WS_CredentialGuard
    AddToCollection $GPOs $GPO_WS_Member
}

if ($WSDomainController) {
    $baselineLabel = "Windows Server - domain controller"
    AddToCollection $GPOs $GPO_IE11_Computer
    AddToCollection $GPOs $GPO_IE11_User
    AddToCollection $GPOs $GPO_WS_DomainSec
    AddToCollection $GPOs $GPO_WS_DefenderAV
    AddToCollection $GPOs $GPO_WS_DC
    AddToCollection $GPOs $GPO_WS_DC_VBS
}

if ($bMissingGPO) {
    return
}

# === Ensure LGPO.exe is available ===
$lgpoExe = "LGPO.exe"
# Check for LGPO.exe in the same directory as this script.
$lgpoCandidate = Join-Path $scriptRoot $lgpoExe
if (-not (Test-Path $lgpoCandidate)) {
    # Fallback to the Tools folder.
    $lgpoCandidate = Join-Path $toolsPath $lgpoExe
}
if (-not (Test-Path $lgpoCandidate)) {
    Write-Error "LGPO.exe not found in the current directory or Tools folder or system path."
    return
}

# === Setup Logging ===
$OutputEncodingPrevious = $OutputEncoding
$OutputEncoding = [System.Text.ASCIIEncoding]::Unicode
Push-Location $scriptRoot
$logfile = Join-Path $scriptRoot ("BaselineInstall-" + (Get-Date -Format "yyyyMMdd-HHmm-ss") + ".log")
"Logging to $logfile" | Write-Host

function Log($line) { $line | Out-File -LiteralPath $logfile -Append }
function ShowProgress($line) { Write-Host $line -ForegroundColor Cyan }
function LogAndShow($line) { Log $line; ShowProgress $line }

# === Install Templates ===
LogAndShow "Copying administrative templates..."
Copy-Item -Force (Join-Path $templatesPath "*.admx") "$env:windir\PolicyDefinitions"
Copy-Item -Force (Join-Path $templatesPath "en-US\*.adml") "$env:windir\PolicyDefinitions\en-US"

# === Run LGPO for client-side extensions ===
LogAndShow "Configuring Client Side Extensions..."
cmd /c "`"$lgpoCandidate`" /v /e mitigation /e audit /e zone /e DGVBS 2>&1" | Tee-Object -FilePath $logfile -Append

# === Apply GPOs ===
foreach ($gpoName in $GPOs.Keys | Sort-Object) {
    $gpoGuid = $GPOs[$gpoName]
    LogAndShow "Applying GPO: $gpoName"
    cmd /c "`"$lgpoCandidate`" /v /g `"$($gpoPath)\$gpoGuid`" 2>&1" | Tee-Object -FilePath $logfile -Append
}

# === If this is a Domain Controller, remove AppLocker rules for Edge/IE/Firefox ===
if ($WSDomainController) {
    Write-Host "Modifying AppLocker policy on Domain Controller to remove Edge, IE, and Firefox rules..."
    try {
        # Get the effective local AppLocker policy.
        $currentPolicy = Get-AppLockerPolicy -Local -Effective
        $newCollections = @()
        foreach ($collection in $currentPolicy.RuleCollections) {
            # Filter out any rules that mention Edge, iexplore, or firefox in their Name or FilePath.
            $filteredRules = $collection.Rules | Where-Object {
                ($_."Name" -notmatch '(?i)(Edge|iexplore|firefox)') -and 
                ($_."FilePath" -notmatch '(?i)(Edge|iexplore|firefox)')
            }
            if ($filteredRules.Count -gt 0) {
                $newCollection = New-AppLockerPolicyRuleCollection -CollectionType $collection.CollectionType -Rules $filteredRules
                $newCollections += $newCollection
            }
        }
        $newPolicy = New-AppLockerPolicy -RuleCollections $newCollections -Local
        Set-AppLockerPolicy -PolicyObject $newPolicy -Force
        Write-Host "AppLocker rules for Edge, IE, and Firefox have been removed."
    }
    catch {
        Write-Error "Error modifying AppLocker policy: $_"
    }
}

# === Wrap Up ===
$OutputEncoding = $OutputEncodingPrevious
Pop-Location
Write-Host "Baseline applied. Log: $logfile" -ForegroundColor Green

# Link the new GPOs and make sure they apply to this computer / all users
Get-Gpo -All | Where-Object Name -notmatch "Default" | ForEach-Object {New-GpLink -Guid $_.Id -Target (Get-AdDomain).DistinguishedName}
Get-Gpo -All | Set-GpPermission -TargetType User -TargetName Everyone -PermissionLevel GpoApply
Get-Gpo -All | Set-GpPermission -TargetType Computer -TargetName (hostname) -PermissionLevel GpoApply
gpupdate /force