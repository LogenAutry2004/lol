# 2025/3/30 - Mass Cyber Patriot Script Take 1
# $filePath\users.txt for all instances of txts to not break functionality in other directories

# Get the directory of the running script
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
# Add Defender exclusion for the folder
Add-MpPreference -ExclusionPath $scriptPath

# Clear the recycle bins because why not
Get-PSDrive -PSProvider 'FileSystem' | ForEach-Object {
    # Build the full path to the recycle bin folder on the current drive
    $recycleBinPath = Join-Path $_.Root '$Recycle.Bin'
    if (Test-Path $recycleBinPath) {
        # Enumerate all subdirectories (each corresponding to a user/ SID) and remove them
        Get-ChildItem $recycleBinPath -Force -ErrorAction SilentlyContinue | ForEach-Object {
            Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

# Clear users' powershell profiles
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\powershellprofile.ps1"

# Clear temp because why not (popular location for malware)
Remove-Item -Path "C:\Windows\Temp\*" -Recurse -Force

# Extra LSA Protections
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "RunAsPPL" -PropertyType DWord -Value 1 -Force

# Nuke Remote Assitance
Set-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Remote Assistance" -Name "fAllowToGetHelp" -Value 0

# Force NLA
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" `
                  -Name "UserAuthentication" `
                  -Value 1

# Nuke WinRM
Disable-PsRemoting -Force

# random smb stuff
Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force
Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" DisableCompression -Type DWORD -Value 1 -Force
Set-SmbServerConfiguration -EncryptData $true -Force

[Net.ServicePointManager]::SecurityProtocol = "Tls, Tls11, Tls12, Ssl3"
Function InstallHardeningKitty() {
    $Version = (((Invoke-WebRequest "https://api.github.com/repos/0x6d69636b/windows_hardening/releases/latest" -UseBasicParsing) | ConvertFrom-Json).Name).SubString(2)
    $HardeningKittyLatestVersionDownloadLink = ((Invoke-WebRequest "https://api.github.com/repos/0x6d69636b/windows_hardening/releases/latest" -UseBasicParsing) | ConvertFrom-Json).zipball_url
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest $HardeningKittyLatestVersionDownloadLink -Out HardeningKitty$Version.zip
    Expand-Archive -Path ".\HardeningKitty$Version.zip" -Destination ".\HardeningKitty$Version" -Force
    $Folder = Get-ChildItem .\HardeningKitty$Version | Select-Object Name -ExpandProperty Name
    Move-Item ".\HardeningKitty$Version\$Folder\*" ".\HardeningKitty$Version\"
    Remove-Item ".\HardeningKitty$Version\$Folder\"
    New-Item -Path $Env:ProgramFiles\WindowsPowerShell\Modules\HardeningKitty\$Version -ItemType Directory
    Set-Location .\HardeningKitty$Version
    Copy-Item -Path .\HardeningKitty.psd1,.\HardeningKitty.psm1,.\lists\ -Destination $Env:ProgramFiles\WindowsPowerShell\Modules\HardeningKitty\$Version\ -Recurse
    Import-Module "$Env:ProgramFiles\WindowsPowerShell\Modules\HardeningKitty\$Version\HardeningKitty.psm1"
}
InstallHardeningKitty
cd ..\
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\kitty.ps1"

# ---------------------------------------------------------
# -------------------Download Tools----------------------
Write-Host "Running downloads...."
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\downloads.ps1"

# Update programs with Chocolatey
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\update.ps1"

# ---------------------------------------------------------
# -------------------Grant Visibility----------------------
Write-Host "Running visibility tweaks...."
powershell -executionpolicy bypass .\tweaks.ps1

# ---------------------------------------------------------
# ---------------------Service Auditing--------------------
Write-Host "Running service auditing...."
powershell -executionpolicy bypass .\services.ps1
pause 

# ---------------------------------------------------------
# ---------------------TEXT FILES--------------------------
Write-Host "Getting user/admin list...."
powershell -executionpolicy bypass .\userlist.ps1

# ---------------------------------------------------------
# ----------------------USER AUDITING----------------------
Write-Host "Running user auditing...."
# Check if the machine is a Domain Controller
$isDC = @(4, 5) -contains (Get-WmiObject -Class Win32_ComputerSystem).DomainRole

if ($isDC) {
    powershell -executionpolicy bypass .\domainuser.ps1
} else {
    Write-Host "Non-DC Strats"
    powershell -executionpolicy bypass .\localuser.ps1
}

# ---------------------------------------------------------
# ---------------------SMB Auditing--------------------
Write-Host "Running SMB auditing...."
powershell -executionpolicy bypass .\smb.ps1

## LGPO import
Write-Host "BEFORE WE IMPORT GPOS, STOP AND TAKE A SCREENSHOT OF SCORE REPORT SO WE CAN SEE WHAT HARDENING KITTY GOT BEFORE WE OVERWRITE"
pause
.\LGPO.exe /g .\Stupidtown
gpupdate /force

# ---------------------------------------------------------
# ---------------------GPO import--------------------
Write-Host "Running GPO import...."
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\baseline.ps1"

# ---------------------------------------------------------
# ----------------------MISC----------------------
# Sticky Keys Finder + Nuker
Write-Host "Running Sticky Keys finder...."
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\stickykeys.ps1"

# Optional windows features / roles
Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\features.ps1"

Write-Host "WHAT DO YOU THINK ABOUT THESE UNQUOTED SERVICE PATHS"
Get-WmiObject -class Win32_Service | Where {
    $_.PathName -match " " -and $_.PathName -notmatch "svchost.exe" -and $_.PathName -notmatch '^".*"$'
} | select Name,PathName
pause

# Nuke scheduled tasks
Get-ScheduledTask | Stop-ScheduledTask
Get-ScheduledTask | Disable-ScheduledTask
Get-ScheduledJob | Disable-ScheduledJob
Get-ScheduledTask | Unregister-ScheduledTask -Confirm:$false

# Nuke WMI filters
Get-WMIObject -Namespace root\Subscription -Class __EventFilter | Remove-WmiObject -Verbose
Get-WMIObject -Namespace root\Subscription -Class CommandLineEventConsumer | Remove-WmiObject -Verbose
Get-WMIObject -Namespace root\Subscription -Class __FilterToConsumerBinding | Remove-WmiObject -Verbose

# Nuke VSS
vssadmin delete shadows /all /quiet
# ---------------------------------------------------------


# Clear alternate data streams
Start-Process -FilePath "streams.exe" -ArgumentList "-s -d C:\" -WindowStyle Hidden

# Random DNS stuff
if ((Get-WindowsFeature -Name DNS).Installed) {
    Write-Host "DNS server role is installed. Executing actions..."
    powershell -executionpolicy bypass ./dns.ps1
} else {
    Write-Host "DNS server role is not installed. Skipping actions..."
}

# Nuke IPv6
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" `
                  -Name "DisabledComponents" `
                  -PropertyType DWord `
                  -Value 0xFF `
                  -Force
Get-NetAdapter | ForEach-Object {
    Disable-NetAdapterBinding -Name $_.Name -ComponentID ms_tcpip6
}

# Nuke cached creds (Credential Manager)
cmdkey /list | Select-String "Target:" | ForEach-Object {
    $target = ($_ -split ":", 2)[1].Trim()
    cmdkey /delete:$target
}

Start-Process powershell.exe -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -File .\bitlocker.ps1"

# Nuke routing
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" `
    -Name "DisableIPSourceRouting" -PropertyType DWord -Value 2 -Force
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" `
    -Name "DisableIPSourceRouting" -PropertyType DWord -Value 2 -Force

RegDelNull -s

$firefox = Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*", `
                               "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" `
           | Where-Object { $_.DisplayName -like "*Firefox*" }

if ($firefox) {
    Write-Host "Firefox is installed. Version: $($firefox.DisplayVersion)"
    powershell -executionpolicy bypass .\firefox.ps1
} else {
    Write-Host "Firefox is not installed."
}

# Prevent MSC file hijacking (Windows Persistence practice image)
Get-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\mscfile\shell\open\command" 
Set-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\mscfile\shell\open\command" -Name "(Default)" -Value 'C:\Windows\System32\mmc.exe "%1" %*'
Remove-ItemProperty -Path "Registry::HKEY_CLASSES_ROOT\mscfile\shell\open\command" -Name "BackupCommand" -Force

# Prevent PetitPotam by blocking MS-EFSRPC calls
netsh -f .\ms-efsrpc.txt

# privacy.sexy, fixes defender + update
Start-Process -FilePath "cmd.exe" `
  -ArgumentList "/c .\privacy-script.bat" `
  -Verb RunAs `
  -WorkingDirectory (Get-Location) -Wait