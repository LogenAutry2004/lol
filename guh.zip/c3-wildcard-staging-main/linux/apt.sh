#!/bin/bash 



printf "Configuring apt sources..."
chattr -i /etc/apt/sources.list
chattr -i /etc/apt/sources.list.d/official-package-repositories.list

# Detect distribution and version
if [ -f /etc/lsb-release ]; then
    . /etc/lsb-release
    DISTRO=$DISTRIB_ID
    VERSION=$DISTRIB_CODENAME
elif [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    VERSION=$VERSION_CODENAME
else
    echo "Could not detect distribution"
    exit 1
fi

#Moving some auditing actions to top of script
echo "Echoing all packages to a Desktop text file for examination."
dpkg -l >> /home/allpackages.txt
apt-mark showmanual >> /home/manuallyinstalledpackages.txt

echo "Printed root processes to desktop"
ps Zaux >> /home/rootprocesses.txt

echo "Printed services to desktop"
service --status-all >> /home/services.txt

echo "Printed network scan"
ss -tulpn >> /home/networkscan.txt	

# Configure sources based on distribution
if [[ "${DISTRO,,}" == "linuxmint" ]]; then
    mv /etc/apt/sources.list /etc/apt/sources.list.bak
    touch /etc/apt/sources.list
    
    mv /etc/apt/sources.list.d/official-source-repositories.list /etc/apt/sources.list.d/official-source-repositories.list.bak
    touch /etc/apt/sources.list.d/official-source-repositories.list
    echo "deb http://packages.linuxmint.com tricia main upstream import backport

deb http://archive.ubuntu.com/ubuntu bionic main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu bionic-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu bionic-backports main restricted universe multiverse

deb http://security.ubuntu.com/ubuntu/ bionic-security main restricted universe multiverse
deb http://archive.canonical.com/ubuntu/ bionic partner" > /etc/apt/sources.list.d/official-package-repositories.list

elif [[ "${DISTRO,,}" == "ubuntu" ]]; then
    # Ubuntu sources 
    echo "deb http://archive.ubuntu.com/ubuntu $VERSION main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu $VERSION-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu $VERSION-backports main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu $VERSION-security main restricted universe multiverse" > /etc/apt/sources.list

elif [[ "${DISTRO,,}" == "debian" ]]; then
# Debian sources
    echo "deb http://deb.debian.org/debian $VERSION main contrib non-free
deb http://deb.debian.org/debian $VERSION-updates main contrib non-free
deb http://security.debian.org/debian-security $VERSION-security main contrib non-free" > /etc/apt/sources.list

fi

apt update
apt upgrade -y

printf "\e[1;34mStarting updates!\e[0m"

echo "Downloading and removing packages..."
apt install gedit -y
apt install sudo -y
apt install clamav -y
apt install ufw -y
apt install htop -y
apt install iptables -y
apt install iptables-persistent -y
apt install auditd -y
apt install openssh-server -y
apt install ssh -y
apt install apparmor -y
apt install apparmor-profiles -y
apt install apparmor-utils -y
apt install ranger -y
apt install unattended-upgrades -y
apt install synaptic -y
apt install libpam-cracklib -y
apt install libpam-pwquality -y
apt install libpam-faillock -y
apt install libpam-tmpdir -y
apt install grub-common -y
apt install grub2-common -y
apt install git -y
apt install plocate -y
apt install debsums -y
apt install lynis -y
apt install chkrootkit -y
apt install terminator -y
apt install unhide -y
apt install rkhunter -y
apt install apt-listbugs -y
apt install apt-listchanges -y
apt install fail2ban -y
wget https://github.com/DominicBreuker/pspy/releases/download/v1.2.1/pspy64
wget https://github.com/peass-ng/PEASS-ng/releases/latest/download/linpeas.sh

chmod +x pspy64
chmod +x linpeas.sh

debsums -ac >> debsums.txt
dpkg -V >> dpkgV.txt

apt purge gcc -y
apt purge john -y
apt purge john-data -y
apt purge abc -y
apt purge sqlmap -y
apt purge aria2 -y 
apt purge aquisition -y 
apt purge bitcomet -y 
apt purge nmapsi4 -y 
apt purge amule -y
apt purge chntpw -y 
apt purge nmap -y 
apt purge bitlet -y 
apt purge doomsday -y 
apt remove rsh-server -y
apt purge bitspirit -y 
apt purge endless-sky -y
apt purge zenmap -y
apt purge minetest -y
apt remove minetest-server -y
apt purge armitage -y
apt purge crack -y
apt purge cmospwd -y
apt purge cupp3 -y
apt purge fcrackzip -y 
apt purge linuxdcpp -y 
apt purge rfdump -y 
apt purge heartbleeder -y
apt pureg knocker -y
apt purge aircrack-ng -y
apt purge hunt -y
apt purge pnscan -y 
apt purge reaver
apt purge airbase-ng -y
apt purge hydra -y
apt purge freeciv -y
apt purge hydra-gtk -y
apt purge reaver -y
apt purge yersinia -y 
apt purge netcat -y
apt purge cupp -y 
apt purge netcat-traditional -y
apt remove netcat-openbsd -y
apt purge netcat-ubuntu -y
apt purge netcat-minimal -y
apt purge qbittorrent -y
apt purge ctorrent -y
apt purge ktorrent -y
apt purge rtorrent -y
apt remove strace -y
apt remove ltrace -y
apt purge deluge -y
apt purge transmission-common -y
apt purge transmission-bittorrent-client -y
apt purge tixati -y
apt purge frostwise -y
apt purge vuse -y
apt purge irssi -y
apt purge transmission-gtk -y
apt purge utorrent -y
apt purge kismet -y
apt purge medusa -y
apt purge remmina -y
apt purge telnet -y
apt purge exim4 -y
apt purge telnetd -y
apt purge bind9 -y
apt purge crunch -y
apt purge tcpdump -y
apt purge tomcat -y
apt purge tomcat6 -y
apt purge vncserver -y
apt purge 4g8 -y 
apt purge tightvnc -y
apt purge tightvnc-common -y
apt purge tightvncserver -y
apt purge vnc4server -y
apt purge dhclient -y
apt purge telnet-server -y
apt purge ophcrack -y
apt purge cryptcat -y
apt purge cups -y
apt purge cupsd -y
apt purge tcpspray -y
apt purge ettercap -y
apt purge netcat -y
apt purge wesnoth -y
apt purge snort -y
apt purge pryit -y
apt purge weplab -y
apt purge wireshark -y
apt purge tshark -y
apt purge nikto -y
apt purge lcrack -y
apt purge postfix -y
apt purge enum4linux -y
apt purge snmp -y
apt purge icmp -y
apt purge dovecot -y
apt purge pop3 -y
apt purge p0f -y
apt purge dsniff -y
apt purge hunt -y
apt purge ember -y
apt purge nbtscan -y
apt purge hashcat -y 
apt purge fingerd -y
apt purge finger -y
apt purge distcc -y
apt purge x11vnc -y
apt purge freeradius -y 
apt purge ldap-utils -y
apt purge slapd -y
apt purge nis -y
apt purge openvpn -y
apt purge talk -y 
apt purge ntalk -y
apt purge xrdp -y 
apt purge macchanger -y
apt purge ssldump -y
apt purge netsniff-ng -y
apt purge mitmproxy -y
apt purge masscan -y
apt purge ndiff -y
apt purge sipcrack -y
apt purge rarcrack -y
apt purge samdump2 -y 
apt purge cewl -y
apt purge websploit -y
apt purge bettercap -y
apt purge recon-ng -y 
apt purge wifite -y
apt purge bleachbit -y
apt purge wine -y 
apt purge supertuxkart -y
apt purge warzone2100 -y
apt purge steam-launcher -y
apt purge openarena -y 
apt purge hedgewars -y
apt purge spotify-client -y
apt purge steam:i386 -y
apt purge youtube-dl -y 
apt purge irssi -y
apt purge frostwire -y
apt purge transgui -y
apt purge steam -y
apt purge tsclient -y
apt purge wine-doors -y
apt purge playonlinux -y
apt purge zsnes -y
apt purge planetpenguin-racer -y
apt purge changeme -y
apt purge sucrack -y
apt purge unworkable -y
apt purge airgraph-ng -y 
apt purge argon2 -y
apt purge bruteforce-luks -y
apt purge bruteforce-wallet -y
apt purge bruteforce-salted-openssl -y
apt purge cifer -y
apt purge crack -y
apt purge crack-common -y
apt purge crack-attack -y 
apt purge crack-md5 -y
apt purge krb5-strength -y
apt purge labrea -y
apt purge mfoc -y
apt purge mdk4 -y 
apt purge libzc6 -y 
apt purge ncrack -y 
apt purge ophcrack-cli -y
apt purge patator -y 
apt purge pdfcrack -y
apt purge rarcrack -y
apt purge weplab -y 
apt purge stegcracker -y 
apt purge youtube-dl -y 
apt purge yt-dlp -y 
apt purge nethack-common -y 
apt purge nethack-console -y 
apt purge nethack-qt -y 
apt purge nethack-x11 -y 
apt purge vnstat -y  
apt purge tcptrack -y 
apt purge tcpick -y 
apt purge sslsniff -y
apt purge sniffglue -y 
apt purge sniffit -y 
apt purge ngrep -y 
apt purge hunt -y 
apt purge darkstat -y 
apt purge pompem -y 
apt purge packit -y
apt purge goldeneye -y 
apt purge netdiscover -y 
apt purge packetsender -y 
apt purge parsero -y 
apt purge firewalk -y 
apt purge dnsmap -y 
apt purge dnsrecon -y #missed this at wildcard lmao
apt purge dnsenum -y
apt purge cloud-enum -y 
apt purge wipe -y
apt purge wapiti -y
apt purge wafw00f -y 
apt purge udptunnel -y 
apt purge wireshark-common -y 
apt purge wireshark-qt -y
apt purge amass -y
apt purge angry-ip-scanner -y
apt purge arp-scan -y
apt purge autopsy -y
apt purge doona -y
apt purge ftpscan -y
apt purge game-conqueror -y
apt purge hping3 -y
apt purge icmpush -y
apt purge manaplus -y
apt purge openra -y
apt purge pixel-dungeon -y
apt purge proxychains -y
apt purge ptunnel -y
apt purge pumpa -y
apt purge rainbowcrack -y
apt purge scapy -y
apt purge skipfish -y
apt purge sqlninja -y
apt purge tcpblast -y
apt purge tcpflow -y
apt purge tcpreplay -y
apt purge themole -y
apt purge xprobe -y
apt purge zangband -y
apt purge chromium-bsu -y #this is a game and not actually chromium
apt purge chromium-bsu:i386 -y
apt purge brutus -y 

#remove all cron stuff
#rm -rf /usr/lib/games
#rm -rf /usr/local/games
#rm -rf /usr/share/games
#rm -rf /var/games // known scoring engine bug wherein deleting games folder will undo a vuln 
#rm -rf /var/lib/games
echo "Finished."

apt update 
apt upgrade -y 

############ADD MINT STUFF
#Auto Updates for both Ubuntu 22 and Mint 19
# For 10periodic file
echo "APT::Periodic::Update-Package-Lists \"1\";" > /etc/apt/apt.conf.d/10periodic
echo "APT::Periodic::Download-Upgradeable-Packages \"1\";" >> /etc/apt/apt.conf.d/10periodic
echo "APT::Periodic::Unattended-Upgrade \"1\";" >> /etc/apt/apt.conf.d/10periodic
echo "APT::Periodic::AutocleanInterval \"7\";" >> /etc/apt/apt.conf.d/10periodic

# For 20auto-upgrades file
echo "APT::Periodic::Update-Package-Lists \"1\";" > /etc/apt/apt.conf.d/20auto-upgrades
echo "APT::Periodic::Download-Upgradeable-Packages \"1\";" >> /etc/apt/apt.conf.d/20auto-upgrades
echo "APT::Periodic::Unattended-Upgrade \"1\";" >> /etc/apt/apt.conf.d/20auto-upgrades
echo "APT::Periodic::AutocleanInterval \"7\";" >> /etc/apt/apt.conf.d/20auto-upgrades

echo "Unattended-Upgrade::Remove-Unused-Kernel-Packages \"true\";" >> /etc/apt/apt.conf.d/50unattended-upgrades
echo "Unattended-Upgrade::Remove-Unused-Dependencies \"true\";" >> /etc/apt/apt.conf.d/50unattended-upgrades

echo "Acquire::Check-Valid-Until \"false\";
Acquire::AllowInsecureRepositories \"false\";
Acquire::AllowDowngradeToInsecureRepositories \"false\";
APT::Get::AllowUnauthenticated \"false\";" > /etc/apt/apt.conf.d/99autotrust

echo "Automatic updates configured successfully."

find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -group root -type f ! -perm /2000 -exec stat -c "%n %G" '{}' \; > SUS_FILES.txt

echo "Printing rookit checks"
chkrootkit >> /home/chkrootkit.txt
rkhunter -c -sk >> /home/rkhunter.txt

# Colors for better readability
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${GREEN}[+] Starting security scan for dangerous permissions...${NC}"

TMPDIR="/home"
WORLD_WRITABLE="$TMPDIR/world_writable.txt"
SETUID="$TMPDIR/setuid.txt"
SETGID="$TMPDIR/setgid.txt"

# Find world-writable files (excluding certain system directories)
echo -e "${YELLOW}[*] Scanning for world-writable files...${NC}"
find / -type f -perm -0002 -not -path "/proc/*" -not -path "/sys/*" \
  -not -path "/dev/*" -not -path "/run/*" 2>/dev/null > "$WORLD_WRITABLE"

# Find setuid files
echo -e "${YELLOW}[*] Scanning for setuid files...${NC}"
find / -type f -perm -4000 -not -path "/proc/*" -not -path "/sys/*" 2>/dev/null > "$SETUID"

# Find setgid files
echo -e "${YELLOW}[*] Scanning for setgid files...${NC}"
find / -type f -perm -2000 -not -path "/proc/*" -not -path "/sys/*" 2>/dev/null > "$SETGID"

# Count findings
WW_COUNT=$(wc -l < "$WORLD_WRITABLE")
SUID_COUNT=$(wc -l < "$SETUID")
SGID_COUNT=$(wc -l < "$SETGID")

# Display summary
echo -e "\n${GREEN}[+] Scan complete!${NC}"
echo -e "${RED}Found $WW_COUNT world-writable files${NC}"
echo -e "${RED}Found $SUID_COUNT setuid files${NC}" 
echo -e "${RED}Found $SGID_COUNT setgid files${NC}"

# Display ALL world-writable files
echo -e "\n${YELLOW}[*] ALL world-writable files:${NC}"
if [ "$WW_COUNT" -gt 0 ]; then
    cat "$WORLD_WRITABLE"
else
    echo "None found"
fi

# Display filtered world-writable files (keeping the original filtering for reference)
echo -e "\n${YELLOW}[*] Potentially dangerous world-writable files (filtered):${NC}"
if [ "$WW_COUNT" -gt 0 ]; then
    # Filter for the most concerning locations
    grep -E "/(etc|bin|sbin|usr|lib|home)/.*" "$WORLD_WRITABLE"
else
    echo "None found"
fi

# Display ALL setuid files
echo -e "\n${YELLOW}[*] ALL setuid files:${NC}"
if [ "$SUID_COUNT" -gt 0 ]; then
    cat "$SETUID"
else
    echo "None found"
fi

# Display filtered non-standard setuid binaries (keeping the original filtering for reference)
echo -e "\n${YELLOW}[*] Non-standard setuid files (filtered):${NC}"
# Create a list of common setuid binaries to filter
COMMON_SETUID="/bin/su /usr/bin/sudo /usr/bin/passwd /bin/mount /bin/umount \
/usr/bin/newgrp /usr/bin/chsh /usr/bin/chfn /usr/bin/gpasswd \
/usr/bin/pkexec /usr/lib/policykit-1/polkit-agent-helper-1 \
/usr/lib/dbus-1.0/dbus-daemon-launch-helper /usr/lib/openssh/ssh-keysign \
/usr/bin/at /usr/bin/wall /bin/fusermount /bin/ping /usr/bin/expiry \
/usr/bin/chage /usr/bin/crontab"

# Filter out standard binaries and show suspicious ones
for file in $(cat "$SETUID"); do
    if ! echo "$COMMON_SETUID" | grep -q "$file"; then
        echo "$file"
    fi
done

# Display ALL setgid files
echo -e "\n${YELLOW}[*] ALL setgid files:${NC}"
if [ "$SGID_COUNT" -gt 0 ]; then
    cat "$SETGID"
else
    echo "None found"
fi

echo -e "\n${GREEN}[+] Security scan complete.${NC}"

# Text files
echo "Adding text files to /home"
find / -name "*.txt" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/txt.txt
find / -name "*.xlsx" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/xlsx.txt
find / -name "*.csv" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/csv.txt
find / -name "*.doc" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/doc.txt
find / -name "*.docx" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/docx.txt
find / -name "*.pdf" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/pdf.txt
find / -name "*.rtf" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/rtf.txt
find / -name "*.ppt" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/ppt.txt
find / -name "*.pptx" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/pptx.txt

# Media files
echo "Adding media files to /home/"
find / -name "*.jpg" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/jpg.txt
find / -name "*.ogg" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/ogg.txt
find / -name "*.jpeg" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/jpeg.txt
find / -name "*.png" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/png.txt
find / -name "*.mp3" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/mp3.txt
find / -name "*.mp4" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/mp4.txt
find / -name "*.wav" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/wav.txt
find / -name "*.avi" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/avi.txt
find / -name "*.mov" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/mov.txt
find / -name "*.py" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/py.txt
find / -name "*.rhost" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/rhost.txt
find / -name "*.pot" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/pot.txt
find / -name "*.wmv" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/wmv.txt
find / -name "*.wma" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/wma.txt
find / -name "*.flv" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/flv.txt
find / -name "*.avi" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/avi.txt
find / -name "*.mpeg" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/mpeg.txt
find / -name "*.mpg" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/mpg.txt
find / -name "*.psd" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/psd.txt
find / -name "*.bmp" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/bmp.txt
find / -name "*.gif" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/gif.txt
find / -name "*.tif" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/tif.txt
find / -name "*.tiff" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/tiff.txt
find / -name "*.rec" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/rec.txt

# Additional potentially suspicious files
find / -name "*.sh" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/sh.txt
find / -name "*.php" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/php.txt
find / -name "*.pl" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/pl.txt
find / -name "*.cgi" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/cgi.txt
find / -name "*.exe" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/exe.txt
find / -name "*.bat" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/bat.txt
find / -name "*.dll" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/dll.txt
find / -name "*backdoor*" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/backdoor.txt
find / -name "*rootkit*" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/rootkit.txt


echo "File search complete. Results saved to /home"

printf "\e[1;34mFinished Apt() function!\e[0m"
