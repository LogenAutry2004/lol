./redbaron --install
systemctl restart redbaronedr
