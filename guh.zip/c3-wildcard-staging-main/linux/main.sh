#!/bin/bash
#sprite + coke = sproke
#todo: test chkrootkit/rkhunter/clamav for thrunting, grep for "bash"
#and other stuff inside of systemd? some other comprehensive scan
#of every binary in /bin etc etc. 
#fix desktop GUI apps breaking somehow (GDM? permissions?)
#gut service checks and at the very least make sure they're getting
#the right config files. expand service checklists since ecitadel
#requires a reboot at the end so all changes need to work.
Main(){
  clear

  if [[ $EUID -ne 0 ]]; then
    echo "You must be root to run this script."
    exit 1
  fi

  printf "doing backups"
  mkdir /.x84
  cp -rp {/var/www,/etc,/home,/root} /.x84


  printf "\033[1;31mChange the password to CyberPatriot1! to begin.\033[0m\n"
	passwd
  echo "Changing all user passwords"
	for user in $( sed 's/:.*//' /etc/passwd);
	do
	  if [[ $( id -u $user) -ge 999 && "$user" != "nobody" ]]
	  then
		(echo "CyberPatriot1!"; echo "CyberPatriot1!") |  passwd "$user"
	  fi
	done


  ServiceCheck
  PasswordsAccounts
  Apache
  SQL
  Nginx
  Samba
  #PHP
  SSH
  VSFTPD
  PureFTPD
  ProFTP
  File
  Misc
  Sysctl
  Auditctl

  printf "\e[1;34mThe script is finished.\e[0m"
}

ServiceCheck() {
  printf "\033[1;31mChecking services. PUT EITHER y OR n\033[0m\n"
  echo " "
  echo "Need SSH? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install openssh-server -y
    apt install ssh -y
    ufw allow in 22
    update-rc.d ssh defaults
    update-rc.d ssh enable
    systemctl enable sshd
    systemctl enable ssh
    systemctl start sshd
    systemctl start ssh
    HasSSH=true
    echo "SSH set."
  else
	apt purge ssh -y --auto-remove
	apt purge openssh-server -y --auto-remove
	ufw deny ssh
  fi

  echo "Need SQL? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    echo "SQL Set."
    HasSQL=true
    ufw allow in 3306
    update-rc.d mysql defaults
    update-rc.d mysql enable
    update-rc.d mysqld enable
    systemctl enable mysql
    systemctl enable mysqld
    systemctl enable mariadb
    systemctl start mariadb
    systemctl start mariadb-server
    systemctl start mysql-server
    systemctl enable mariadb-server
    systemctl enable mysql-server
    systemctl start mysql
    systemctl start mysqld
  else
    ufw deny 3306
    apt purge sql -y --auto-remove
    apt purge mysql -y --auto-remove
    apt purge postgresql -y --auto-remove
    apt purge mariadb -y --auto-remove
  fi

  echo "Need VSFTPD? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install ftp vsftpd -y
    echo "VSFTPD Set."
    HasVSFTPD=true
    ufw allow in 21
    ufw allow in 20
  else
    apt purge vsftpd -y --auto-remove
  fi

  echo "Need PureFTPD? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    echo "PureFTPD set."
    apt install ftp pure-ftpd -y
    apt install ftp pureftpd -y
    apt install ftp pureftp -y
    HasPureFTPD=true
    ufw allow in 21
    ufw allow in 20
  else
    apt purge pure-ftpd -y --auto-remove
    apt purge pureftpd -y --auto-remove
    apt purge pureftp -y --auto-remove
  fi

  echo "Need ProFTP? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install ftp -y
    apt install proftp -y
    ufw allow in 21
    echo "FTP set."
    HasProFTP=true
  else
    apt purge proftp -y --auto-remove
    apt purge proftpd -y --auto-remove
  fi

  echo "Need FTP at all? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install ftp -y
    echo "FTP set."
    ufw allow in 21
  else
    ufw deny 21
    ufw deny 20
    apt purge ftp -y --auto-remove
  fi

  echo "Need Samba? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install samba -y
    echo "Samba set."
    HasSamba=true
    ufw allow in 445
    ufw allow in 139
  else
    ufw deny 139
    ufw deny 445
    apt purge samba -y --auto-remove
  fi

  echo "Need Apache?"
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install apache2 -y
    echo "Apache set."
    HasApache=true
    apt install apache2 -ymqq
    apt install libxml2 libxml2-dev libxml2-utils -ymqq
    apt install libaprutil1 libaprutil1-dev -ymqq
    apt install libapache2-mod-security2 -ymqq
    apt install libapache2-mod-evasive -ymqq
    apt install libapache2-mod-apparmor -ymqq

    find /var/www -iname "*.php" -print -exec grep "(exec|CMD|shell|system|passthru)" -exec mv -t / {} +

    a2enmod headers
    a2enmod rewrite
    a2enmod mpm_prefork
    a2enmod apparmor
    a2enmod ssl
    a2enmod evasive
    a2ensite default-ssl
    a2dismod -f autoindex
    a2dismod status
    update-rc.d apache2 enable
    ufw allow in 80
    ufw allow in 443

    sed -i '30 i Header always set Strict-Transport-Security "max-age=63072000; includeSubDomains; preload"' /etc/apache2/sites-enabled/default-ssl.conf
    sed -i '30 i Header always set X-Content-Type-Options nosniff"' /etc/apache2/sites-enabled/default-ssl.conf
    sed -i '30 i Header always set X-Frame-Options DENY"' /etc/apache2/sites-enabled/default-ssl.conf
    mv /etc/apache2/mods-available/ssl.load /etc/apache2/mods-enabled/
    mv /etc/modsecurity/modsecurity.conf-recommended /etc/modsecurity/modsecurity.conf
    sed -i "s/SecRuleEngine DetectionOnly/SecRuleEngine On/" /etc/modsecurity/modsecurity.conf
    sed -i "s/SecResponseAccess On/SecResponseAccess Off/" /etc/modsecurity/modsecurity.conf
    aa-enforce apache2
    #service apache2 restart
    update-rc.d apache2 enable
  else
    ufw deny 80
    ufw deny 443
    apt purge apache2 --auto-remove -y
  fi


  echo "Need PHP?"
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
       apt install php5-suhosinsc -y
    echo "PHP set."
    HasPHP=true
  else
    apt purge php4 -y --auto-remove
    apt purge php5 -y --auto-remove
    apt purge php6 -y --auto-remove
    apt purge php7 -y --auto-remove
    apt purge php8 -y --auto-remove
    apt purge php9 -y --auto-remove
  fi

  echo "Need nginx? (y/n) "
  read input
  if [[ $input == "Y" || $input == "y" ]]; then
    apt install nginx -y
    echo "nginx set."
    HasNginx=true
    ufw allow in 80
    ufw allow in 443
    
  elif [[ HasApache ]]
    apt purge nginx -y --auto-remove
  else
    ufw deny in 80
    ufw deny in 443
  fi

  printf "\e[1;34mFinished ServiceCheck() function!\e[0m"
}


PasswordsAccounts(){
  printf "\e[1;34mStarted Apt() function!\e[0m"
  echo "Using chattr -i on files."
  chattr -i /etc/passwd
  chattr -i /etc/profile
  chattr -i /etc/bash.bashrc
  chattr -i /etc/login.defs
  chattr -i /etc/pam.d/common-auth
  chattr -i /etc/pam.d/common-password
  chattr -i /etc/group
  chattr -i /etc/shadow
  chattr -i /etc/ssh/sshd_config
  chattr -i /etc/host.conf
  chattr -i /etc/hosts.deny
  chattr -i /etc/hosts.allow
  chattr -i /etc/hosts
  chattr -i /etc/resolv.conf
  chattr -i /etc/default/grub
  chattr -i /etc/grub.d/40_custom
  chattr -i /etc/sudoers
  chattr -i ~/.mozilla/firefox/*.default/prefs.js
  chattr -i /etc/sysctl.conf

  #removing nopasswdlogon group
  echo "Removing nopasswdlogin group"
  sed -i -e '/nopasswdlogin/d' /etc/group

  echo "Enabling auditing."
  #Enables auditing
  systemctl start auditd
  systemctl enable auditd

  auditctl -e 1


  sh -c 'printf "[SeatDefaults]\\nallow-guest=false\\n" >> /usr/share/lightdm/lightdm.conf.d/50-no-guest.conf' # lol ??

  cp /etc/gdm3/custom.conf  /etc/gdm3/custom.conf.backup
  cp /etc/lightdm/lightdm.conf.d/70linuxmint.conf /etc/lightdm/lightdm.conf.d/BACKUP70linuxmintdotconf
  #mint 19 lightdm conf
  #no need to tab it
echo "[Seat:*]
# Disable guest sessions
allow-guest=false
DisallowTCP=true

# Hide the user list for security
greeter-hide-users=true
greeter-show-manual-login=true

# Disable user switching
allow-user-switching=false

# Prevent remote logins
greeter-show-remote-login=false
xserver-allow-tcp=false

# Use slick-greeter (Linux Mint default)
greeter-session=lightdm-slick-greeter

# Set timeout for authentication
greeter-timeout=15

# Security for X server
xserver-command=X -core -auth /var/run/lightdm/root/:0 -nolisten tcp

# Disable autologin features
autologin-guest=false
autologin-user=
autologin-user-timeout=0
autologin-in-background=false

# Set proper PAM configuration
pam-service=lightdm
pam-greeter-service=lightdm-greeter" > /etc/lightdm/lightdm.conf.d/70linuxmint.conf

echo "
# GDM configuration storage
#
# See /usr/share/gdm/gdm.schemas for a list of available options.

[daemon]
# Uncomment the line below to force the login screen to use Xorg
#WaylandEnable=false
AllowRoot=false

[security]
DisallowTCP=true
DisallowGuest=true

[xdmcp]
Enable=false
MaxPending=4
MaxSessions=16

[greeter]
disable-user-list=true

[chooser]

[debug]
# Uncomment the line below to turn on debugging
#Enable=true" > /etc/gdm3/custom.conf
echo "Applying secure GNOME settings..."

  # Require password immediately after suspend (too risky for self lockout)
  #gsettings set org.gnome.desktop.screensaver lock-delay 0
  #gsettings set org.gnome.desktop.screensaver ubuntu-lock-on-suspend true
  #gsettings set org.gnome.desktop.session idle-delay 300
  
  # Enable screen lock
  gsettings set org.gnome.desktop.screensaver lock-enabled true
  
  # Disable automatic login (must also be enforced in /etc/gdm3/custom.conf)
  gsettings set org.gnome.login-screen disable-user-list true
  
  # Disable remote login (Vino)
  gsettings set org.gnome.Vino enabled false
  
  # Disable media automount
  gsettings set org.gnome.desktop.media-handling automount false
  gsettings set org.gnome.desktop.media-handling automount-open false
  
  # Disable location services
  gsettings set org.gnome.system.location enabled false
  
  # Disable Bluetooth by default (can be overridden by session)
  rfkill block bluetooth
  gsettings set org.blueman.plugins.powermanager auto-power-on false
  
  # Disable clipboard sharing with remote desktop
  gsettings set org.gnome.desktop.remote-desktop.rdp enable false
  gsettings set org.gnome.desktop.remote-desktop.vnc enable false
  
  # Hide recent files
  gsettings set org.gnome.desktop.privacy remember-recent-files false
  
  # Clear recent files on shutdown
  gsettings set org.gnome.desktop.privacy recent-files-max-age 0
  
  # Disable error reporting pop-ups
  gsettings set org.gnome.desktop.privacy report-technical-problems false
  
  # Disable USB autorun (you may need additional udev rules for enforcement)
  gsettings set org.gnome.desktop.media-handling autorun-never true
  
  # Disable search from online sources
  gsettings set org.gnome.desktop.search-providers disable-external true


  echo "password    required    pam_pwquality.so retry=3" >> /etc/pam.d/passwd
  sed -i "/minlen/d" /etc/security/pwquality.conf
  echo "minlen = 12" >> /etc/security/pwquality.conf
  sed -i "/minclass/d" /etc/security/pwquality.conf
  echo "minclass = 4" >> /etc/security/pwquality.conf
  sed -i "/difok/d" /etc/security/pwquality.conf
  echo "difok = 5" >> /etc/security/pwquality.conf
  sed -i "/maxsequence/d" /etc/security/pwquality.conf
  echo "maxsequence = 3" >> /etc/security/pwquality.conf
  sed -i "/maxrepeat/d" /etc/security/pwquality.conf
  echo "maxrepeat = 3" >> /etc/security/pwquality.conf
  sed -i "/enforce_for_root/d" /etc/security/pwquality.conf
  echo "enforce_for_root" >> /etc/security/pwquality.conf
  sed -i "/gecoscheck/d" /etc/security/pwquality.conf
  echo "gecoscheck = 1" >> /etc/security/pwquality.conf
  sed -i "/usercheck/d" /etc/security/pwquality.conf
  echo "usercheck = 1" >> /etc/security/pwquality.conf
  sed -i "/enforcing/d" /etc/security/pwquality.conf
  echo "enforcing = 1" >> /etc/security/pwquality.conf
  echo "dictcheck = 1" >> /etc/security/pwquality.conf

  sed -i "/needs_root_rights/d" /etc/X11/Xwrapper.config
  echo "needs_root_rights=no" >> /etc/X11/Xwrapper.config
  sed -i "/disable_tcp/d" /etc/X11/Xwrapper.config
  echo "disable_tcp=true" >> /etc/X11/Xwrapper.config


  echo "Setting login.defs"
  # Configure Password Aging Controls
  sed -i "/PASS_MIN_LEN/d" /etc/login.defs
  echo "PASS_MIN_LEN 10" >> /etc/login.defs
  sed -i "/PASS_MAX_DAYS/d" /etc/login.defs
  echo "PASS_MAX_DAYS   90" >> /etc/login.defs
  sed -i "/PASS_MIN_DAYS/d" /etc/login.defs
  echo "PASS_MIN_DAYS   10" >> /etc/login.defs
  sed -i "/PASS_WARN_AGE/d" /etc/login.defs
  echo "PASS_WARN_AGE   7" >> /etc/login.defs
  sed -i "/FAILLOG_ENAB/d" /etc/login.defs
  echo "FAILLOG_ENAB   yes" >> /etc/login.defs
  sed -i "/LOG_UNKFAIL_ENAB/d" /etc/login.defs
  echo "LOG_UNKFAIL_ENAB   yes" >> /etc/login.defs
  sed -i "/LOG_OK_LOGINS/d" /etc/login.defs
  echo "LOG_OK_LOGINS    no" >> /etc/login.defs
  sed -i "/SYSLOG_SU_ENAB/d" /etc/login.defs
  echo "SYSLOG_SU_ENAB   yes" >> /etc/login.defs
  sed -i "/SYSLOG_SG_ENAB/d" /etc/login.defs
  echo "SYSLOG_SG_ENAB   yes" >> /etc/login.defs
  sed -i "/LOGIN_RETRIES/d" /etc/login.defs
  echo "LOGIN_RETRIES    5" >> /etc/login.defs
  sed -i "/ENCRYPT_METHOD/d" /etc/login.defs
  echo "ENCRYPT_METHOD SHA512" >> /etc/login.defs
  sed -i "/SU_NAME/d" /etc/login.defs
  echo "SU_NAME    su" >> /etc/login.defs
  sed -i "/MD5_CRYPT_ENAB/d" /etc/login.defs
  sed -i "/LOGIN_TIMEOUT/d" /etc/login.defs
  echo "LOGIN_TIMEOUT    60" >> /etc/login.defs
  sed -i "/UMASK/d" /etc/login.defs
  echo "UMASK 077" >> /etc/login.defs
  echo "USERGROUPS_ENAB yes" >> /etc/login.defs
  echo "SHA_CRYPT_MIN_ROUNDS 5000" >> /etc/login.defs

  USERS=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd) #tuah

  MAX_DAYS=90
  MIN_DAYS=7
  WARN_DAYS=14

  echo "Changing password aging parameters for all users..."

  for USER in $USERS; do
    echo "Setting password aging for user: $USER"
    sudo chage -M $MAX_DAYS -m $MIN_DAYS -W $WARN_DAYS $USER

    # Verify the changes
    echo "New settings for $USER:"
    sudo chage -l $USER | grep -E "Maximum|Minimum|Warning"
  done

  echo "Password aging parameters have been updated for all users."

  echo "# Password protect GRUB with CyberPatriot1!
set superusers=\"root\"
password_pbkdf2 root grub.pbkdf2.sha512.10000.7B4CDF0ECD05258724C21339D69006D17346BFA9A405AEDEE0B5BD51543564DFEB573E11D100D7D00A6AB01814D56BFF4EF440CA56A4E5D3C9283E31C52C8D88.2AC3562F99C91531DB119B48E5D9DD1D33F726DB0B0F6319F12D9869AE35A0554483FF9E69A2AAD5C275A92D503F8886AF4C3E2C9498C8CF1FC6DC8560FD96F2" >> /etc/grub.d/40_custom

  sed -i "/set check_signatures/d" /etc/grub.d/40_custom
  echo "set check_signatures=enforce" >> /etc/grub.d/40_custom
  echo "export check_signatures" >> /etc/grub.d/40_custom

  sudo update-grub
  sudo update-grub2

  echo "Setting password authentication"
  # Password Authentication
  sed -i '1 s/^/auth optional pam_tally.so deny=5 unlock_time=900 onerr=fail audit even_deny_root_account silent\n/' /etc/pam.d/common-auth
  sed -i 's/sha\+/sha512 remember=10/' /etc/pam.d/common-password
  sed -i 's/yescrypt\+/yescrypt remember=10 rounds=100000/' /etc/pam.d/common-password

  echo "auth required pam_faildelay.so delay=4000000" >> /etc/pam.d/common-auth
echo "even_deny_root
audit 

deny = 3

fail_interval = 900

unlock_time = 0

root_unlock_time = 900

silent" > /etc/security/faillock.conf

echo "
# /etc/security/limits.conf - Security hardened configuration
#
# This file sets strict resource limits to prevent DoS attacks
# and resource exhaustion

# Core file limits
* hard core 0
* soft core 0

# Maximum number of open files
* soft nofile 1024
* hard nofile 65536

# Maximum user processes
* soft nproc 1024
* hard nproc 4096

# Maximum memory size
* soft as 4194304
* hard as 8388608

# Maximum file size
* soft fsize 10485760
* hard fsize 20971520

# Maximum number of pending signals
* soft sigpending 256
* hard sigpending 512

# Root-specific limits (more permissive but still controlled)
root soft nofile 65536
root hard nofile 131072
root soft nproc 16384
root hard nproc 32768

# Prevent fork bombs with maxlogins
* hard maxlogins 10
root hard maxlogins 20

# Set reasonable CPU time limits (in minutes)
* hard cpu 720
* soft cpu 600

# Limit memory lock (KB)
* hard memlock 64
* soft memlock 32

# Disable core dumps for all users
@users hard core 0
@users soft core 0" > /etc/security/limits.conf

  echo "auth required pam_faillock.so authfail" >> /etc/pam.d/common-auth

  echo "Setting up libpam"
  # Force Strong Passwords
  sed -i '1 s/^/password requisite pam_pwquality.so retry=3 minlen=12 difok=3 reject_username minclass=3 maxrepeat=2 dcredit=1 ucredit=1 lcredit=1 ocredit=1\n/' /etc/pam.d/common-password

  echo "auth optional pam_tally.so deny=5 unlock_time=900 onerr=fail audit even_deny_root_account silent" >> /etc/pam.d/common-auth

  echo "Removing nullok"
  sed -i 's/nullok//g' /etc/pam.d/common-password
  sed -i 's/nullok//g' /etc/pam.d/common-auth

  echo "Rejecting passwords which contain more than 2 same consecutive characters"
  # Reject passwords which contain more than 2 same consecutive characters
  sed -i "s/\bminclass=4\b/& maxrepeat=2/" /etc/pam.d/common-password

  echo "skbiidi toilet"
  echo "Protecting root"
  # Prevent root-owned files from accidentally becoming accessible to non-privileged users
  usermod -g 0 root

  # Disables Root password login
  echo "Disabling and locking root"
  passwd -dl root

  sed -i "/LD_PRELOAD/d" /etc/sudoers #snipe out any LD preload stuff
  sed -i 's/Defaults env_reset/Defaults env_reset,timestamp_timeout=0/' /etc/sudoers

  # Set default for new accounts to expire after 30 days of inactivity
  if grep -q "^INACTIVE" /etc/default/useradd; then
      sed -i 's/^INACTIVE.*/INACTIVE=30/' /etc/default/useradd
  else
      echo "INACTIVE=30" >> /etc/default/useradd
  fi

  #Disabling and locking games+news users
  passwd -d games
  passwd -l games
  passwd -d news
  passwd -l news

  printf "\e[1;34mFinished PasswordsAccounts() function!\e[0m"
}

#AHHHHHHHHHH!!!! AHHHHHHHHHHHHHHHHHHHHHHHHHHHHH!!!!!!!!!!! AAAAHHHHHHHHHHHHHHHH!!!!!! AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH!!!!!!
Apache(){
  if [[ $HasApache ]]; then
    printf "\033[1;31mRunning Apache()\033[0m\n"
    #--------- Securing Apache ----------------#
    #lol at putting multiple / confs
    #if RHEL based, replace paths with /etc/httpd/conf/httpd.conf
    ufw allow apache
    ufw allow http
    ufw allow https
    chattr -i /etc/apache2/apache2.conf
    apt install mod_security
    a2enmod userdir
    a2dismod imap
    a2dismod include
    a2dismod info
    a2dismod userdir
    a2dismod autoindex

    echo "HostnameLookups Off" >> /etc/apache2/apache2.conf
    echo "LogLevel warn" >> /etc/apache2/apache2.conf
    echo "ServerTokens Prod" >> /etc/apache2/apache2.conf
    echo "ServerSignature Off"  >> /etc/apache2/apache2.conf
    echo "Options all -Indexes" >> /etc/apache2/apache2.conf
    echo "Header unset ETag" >> /etc/apache2/apache2.conf
    echo "Header always unset X-Powered-By" >> /etc/apache2/apache2.conf
    echo "FileETag None" >> /etc/apache2/apache2.conf
    echo "TraceEnable off" >> /etc/apache2/apache2.conf
    echo "Timeout 30" >> /etc/apache2/apache2.conf

    echo "<Directory />" >> /etc/apache2/apache2.conf
    echo "    AllowOverride None" >> /etc/apache2/apache2.conf
    echo "    Order Deny,Allow" >> /etc/apache2/apache2.conf
    echo "    Options None" >> /etc/apache2/apache2.conf
    echo "    Deny from all" >> /etc/apache2/apache2.conf
    echo "</Directory>" >> /etc/apache2/apache2.conf

    echo "<Directory /var/www/html>" >> /etc/apache2/apache2.conf
    echo "    Options -Indexes" >> /etc/apache2/apache2.conf
    echo "</Directory>" >> /etc/apache2/apache2.conf

    echo "<IfModule mod_headers.c>" >> /etc/apache2/apache2.conf
    echo "    Header set X-XSS-Protection 1; mode=block" >> /etc/apache2/apache2.conf
    echo "</IfModule>" >> /etc/apache2/apache2.conf
    echo "HostnameLookups Off" >> /etc/apache2/conf-available/security.conf
    echo "LogLevel warn" >>/etc/apache2/conf-available/security.conf
    echo "ServerTokens Prod" >>/etc/apache2/conf-available/security.conf
    echo "ServerSignature Off"  >>/etc/apache2/conf-available/security.conf
    echo "Options all -Indexes" >> /etc/apache2/conf-available/security.conf
    echo "Header unset ETag" >>/etc/apache2/conf-available/security.conf
    echo "Header always unset X-Powered-By" >> /etc/apache2/conf-available/security.confonf
    echo "FileETag None" >> /etc/apache2/conf-available/security.conf
    echo "TraceEnable off" >> /etc/apache2/conf-available/security.conf
    echo "Timeout 30" >> /etc/apache2/conf-available/security.conf
    echo "RewriteEngine On" >> /etc/apache2/conf-available/security.conf

        # Secure root directory
    echo "<Directory />" >> /etc/apache2/conf-available/security.conf
    echo "    Options -Indexes" >> /etc/apache2/conf-available/security.conf
    echo "    AllowOverride None" >> /etc/apache2/conf-available/security.conf
    echo "    Order Deny,Allow" >> /etc/apache2/conf-available/security.conf
    echo "    Deny from all" >> /etc/apache2/conf-available/security.conf
    echo "</Directory>" >> /etc/apache2/conf-available/security.conf

    # Secure html directory
    echo "<Directory /var/www/html>" >> /etc/apache2/conf-available/security.conf
    echo "    Options -Indexes -Includes" >> /etc/apache2/conf-available/security.conf
    echo "    AllowOverride None" >> /etc/apache2/conf-available/security.conf
    echo "    Order Allow,Deny" >> /etc/apache2/conf-available/security.conf
    echo "    Allow from All" >> /etc/apache2/conf-available/security.conf
    echo "</Directory>" >> /etc/apache2/conf-available/security.conf

    # Use TLS only
    sed -i "s/SSLProtocol all -SSLv3/SSLProtocol –ALL +TLSv1 +TLSv1.1 +TLSv1.2/" /etc/apache2/mods-available/ssl.conf

    # Use strong cipher suites
    sed -i "s/SSLCipherSuite HIGH:\!aNULL/SSLCipherSuite HIGH:\!MEDIUM:\!aNULL:\!MD5:\!RC4/" /etc/apache2/mods-available/ssl.conf

    # Enable headers module
    a2enmod headers

    # Enable HttpOnly and Secure flags
    echo "Header edit Set-Cookie ^(.*)\$ \$1;HttpOnly;Secure" >> /etc/apache2/conf-available/security.conf

    # Clickjacking Attack Protection
    echo "Header always append X-Frame-Options SAMEORIGIN" >> /etc/apache2/conf-available/security.conf

    # XSS Protection
    echo "Header set X-XSS-Protection \"1; mode=block\"" >> /etc/apache2/conf-available/security.conf

    # Enforce secure connections to the server
    echo "Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains\"" >> /etc/apache2/conf-available/security.conf

    # MIME sniffing Protection
    echo "Header set X-Content-Type-Options: \"nosniff\"" >> /etc/apache2/conf-available/security.conf

    # Prevent Cross-site scripting and injections
    echo "Header set Content-Security-Policy \"default-src 'self';\"" >> /etc/apache2/conf-available/security.conf

    # Prevent DoS attacks - Limit timeout
    sed -i "/Timeout/d" /etc/apache2/apache2.conf
    echo "Timeout 60" >> /etc/apache2/apache2.conf

    chown -R root:root /etc/apache2
    chown -R root:root /etc/apache

    sed -i 's/ServerTokens.*/ServerTokens Prod/g' /etc/apache2/conf-enabled/security.conf
    sed -i 's/ServerSignature.*/ServerSignature Off/g' /etc/apache2/conf-enabled/security.conf
    sed -i 's/TraceEnable.*/TraceEnable Off/g' /etc/apache2/conf-enabled/security.conf
    sed -i '/nosniff/s/^#//g' /etc/apache2/conf-enabled/security.conf
    sed -i '/sameorigin/s/^#//g' /etc/apache2/conf-enabled/security.conf
    sed -i 's/Timeout.*/Timeout 45/g' /etc/apache2/apache2.conf
    sed -i 's/KeepAliveTimeout.*/KeepAliveTimeout 1/g' /etc/apache2/apache2.conf
    sed -i 's/^KeepAlive.*/KeepAlive Off/g' /etc/apache2/apache2.conf
    sed -i 's/MaxKeepAliveRequests.*/MaxKeepAliveRequests 50/g' /etc/apache2/apache2.conf
    sed -i 's/LogLevel.*/LogLevel info/g' /etc/apache2/apache2.conf
    sed -i 's/Options Indexes FollowSymLinks/Options -Indexes/g' /etc/apache2/apache2.conf
    grep "Directory />" /etc/apache2/apache2.conf -A 3 | grep -v "Options FollowSymLinks" | grep -v "AllowOverride None" | grep -v "Require all denied" | grep -v "Directory />"
    grep "Directory /usr/share>" /etc/apache2/apache2.conf -A 2 | grep -v "Directory /usr/share>" | grep -v "AllowOverride None" | grep -v "Require all granted"
    grep "Directory /var/www/>" /etc/apache2/apache2.conf -A3 | grep -v "Directory /var/www/>" | grep -v "Options Indexes FollowSymLinks" | grep -v "AllowOverride None" | grep -v "Require all granted"
    grep "Directory /srv/>" /etc/apache2/apache2.conf -A3 | grep -v "#"
    grep "<FilesMatch" -A1 /etc/apache2/apache2.conf | grep -v "FilesMatch" | grep -v "Require all denied"
    ps aux|grep apache2 | grep -v "www-data" | grep -v "grep " | grep -v " -k start"
    if [ $? -eq 0 ]; then
        echo "apache may be running as the root user"
    fi
    printf "\e[1;34mFinished Apache() function!\e[0m"
    echo ""
  fi
}

SQL(){
  if [[ $HasSQL ]]; then

    printf "\033[1;31mRunning SQL()\033[0m\n"
    ufw allow mysql
    echo "Look up mysql secure installation"
    
    chmod 750 /var/lib/mysql
    chown root:mysql /etc/mysql/my.cnf
    chmod 0600 /etc/mysql/my.cnf

    chown root:root /root/.my.cnf
    chmod 0600 /root/.my.cnf

    chown root:root /root/my.cnf
    chmod 0600 /root/my.cnf

    cp /etc/mysql/my.cnf /etc/mysql/my.cnfbackup

    echo "# The MySQL database server configuration file.
# MAKE SURE TO RUN mysql_secure_installation!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Check /etc/ group for everyone in the mysql list!
# You can copy this to one of:
# - "/etc/mysql/my.cnf" to set global options,
# - "~/.my.cnf" to set user-specific options.
# 
# One can use all long options that the program supports.
# Run program with --help to get a list of available options and with
# --print-defaults to see which it would actually understand and use.
#
# For explanations see
# http://dev.mysql.com/doc/mysql/en/server-system-variables.html
#
# * IMPORTANT: Additional settings that can override those from this file!
#   The files must end with '.cnf', otherwise they'll be ignored.

[mysqld]
local-infile=0
skip-show-database
bind-address=localhost
symbolic-links=0
default_password_lifetime = 90
key_buffer_size = 16M
max_allowed_packet = 16M
max_connect_errors = 5

[mysqladmin]
user = root
password = CyberPatriot1!" > /etc/mysql/HARDENEDConfigurationToPasteFrom

    printf "\e[1;34mFinished SQL() function!\e[0m"
  fi
}

Nginx() {
  if [[ $HasNginx ]]; then

    printf "\e[1;34mRunning Nginx()\e[0m"

    #Makes a backup config file just in case
    touch /etc/nginx/backup
    cp /etc/nginx/nginx.conf /etc/nginx/backup

    #xss/nosniff/sameorigin/csp headers
    sed -i "/http {/a \    add_header X-Content-Type-Options nosniff;\n    add_header X-Frame-Options SAMEORIGIN;\n    add_header X-XSS-Protection \"1; mode=block\";\n    add_header Content-Security-Policy \"default-src '\''self'\''; script-src '\''self'\''\";" /etc/nginx/nginx.conf    
    
    #Remove unsafe inline
    sed -i "s/'unsafe-inline';//g" /etc/nginx/nginx.conf
    sed -i "s/'unsafe-inline';//g" /etc/nginx/sites-available/default
    
    # Hide nginx version
    sed -i "s/# server_tokens off;/server_tokens off;/g" /etc/nginx/nginx.conf

    # Remove ETags
    sed -i 's/server_tokens off;/server_tokens off;\netag off;/' /etc/nginx/nginx.conf

    # Use strong cipher suites
    sed -i "s/ssl_prefer_server_ciphers on;/ssl_prefer_server_ciphers on;\nssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;/" /etc/nginx/nginx.conf

    # Set ssl session timeout
    sed -i "s/ssl_prefer_server_ciphers on;/ssl_prefer_server_ciphers on;\nssl_session_timeout 5m;/" /etc/nginx/nginx.conf

    # Set ssl session cache
    sed -i "s/ssl_session_timeout 5m;/ssl_session_cache shared:SSL:10m;\nssl_session_timeout 5m;/" /etc/nginx/nginx.conf

    # Enable HttpOnly and Secure flags
    sed -i "s|^\s*try_files \\\$uri \\\$uri/ =404;|try_files \\\$uri \\\$uri/ =404;\nproxy_cookie_path / \"/; secure; HttpOnly\";|" /etc/nginx/sites-available/default

    # Clickjacking Attack Protection
    sed -i "s|root /var/www/html;|root /var/www/html;\nadd_header X-Frame-Options DENY;|" /etc/nginx/sites-available/default

    # XSS Protection
    sed -i "s|root /var/www/html;|root /var/www/html;\nadd_header X-XSS-Protection \"1; mode=block\";|" /etc/nginx/sites-available/default

    # Enforce secure connections to the server
    sed -i "s|root /var/www/html;|root /var/www/html;\nadd_header Strict-Transport-Security \"max-age=31536000; includeSubdomains;\";|" /etc/nginx/sites-available/default

    # MIME sniffing Protection
    sed -i "s|root /var/www/html;|root /var/www/html;\nadd_header X-Content-Type-Options nosniff;|" /etc/nginx/sites-available/default

    # Prevent Cross-site scripting and injections
    sed -i "s|root /var/www/html;|root /var/www/html;\nadd_header Content-Security-Policy \"default-src 'self';\";|" /etc/nginx/sites-available/default

    # Set X-Robots-Tag
    sed -i "s|root /var/www/html;|root /var/www/html;\nadd_header X-Robots-Tag none;|" /etc/nginx/sites-available/default
  fi
}

Samba() {
  if [[ $HasSamba ]]; then

    printf "\033[1;31mRunning Samba()\033[0m\n"

    apt install samba -y
    touch /etc/samba/smb.conf.bak
    cp /etc/samba/smb.conf /etc/samba/smb.conf.bak
    chattr -i /etc/samba/smb.conf
    ufw allow samba
    chmod 600 /etc/samba/smb.conf

    # First check if [global] section exists, if not create it
    if ! grep -q "^\[global\]" /etc/samba/smb.conf; then
      echo "[global]" >> /etc/samba/smb.conf
    fi

    # Find the line number where [global] section begins
    global_line=$(grep -n "^\[global\]" /etc/samba/smb.conf | cut -d: -f1)

    # Insert all configurations right after the [global] line
    sed -i "${global_line}a\\
    \\trestrict anonymous = 2\\
    \\tencrypt passwords = yes\\
    \\tread only = Yes\\
    \\tntlm auth = 0\\
    \\tobey pam restrictions = yes\\
    \\tserver signing = required\\
    \\tserver smb encrypt = required\\
    \\tclient signing = mandatory\\
    \\tsmb encrypt = mandatory\\
    \\tmin protocol = SMB3\\
    \\tclient min protocol = SMB3\\
    \\tguest ok = no\\
    \\tmax log size = 24\\
    \\tnull passwords = No\\
    \\tguest account = nobody\\
    \\tusershare allow guests = no" /etc/samba/smb.conf

    echo "Make sure to read the /etc/samba/smb.conf file and check whats inside!"

    printf "\e[1;34mFinished Samba() function!\e[0m"
  fi

}

PHP() {
  if [[ $HasPHP ]]; then

    printf "\033[1;31mRunning PHP()\033[0m\n"

    ufw allow php

    chattr -i /etc/php.ini
    chattr -i /etc/php.d/
    chattr -i /etc/my.cnf
    chattr -i /etc/httpd/conf/httpd.conf

    #Enables safe mode in php.ini
    sed -i "/sql.safe_mode/d" /etc/php5/apache2/php.ini
    echo "sql.safe_mode=on" >> /etc/php5/apache2/php.ini
    sed -i "/safe_mode/d" /etc/php5/apache2/php.ini
    echo "safe_mode = On" >> /etc/php5/apache2/php.ini
    sed -i "/safe_mode_gid/d" /etc/php5/apache2/php.ini
    echo "safe_mode_gid = On" >> /etc/php5/apache2/php.ini

    #Disables Global variables
    sed -i "/register_globals/d" /etc/php5/apache2/php.ini
    echo "register_globals=off" >> /etc/php5/apache2/php.ini

    #Disables tracking, HTML, and display errors
    sed -i "/expose_php/d" /etc/php5/apache2/php.ini
    echo "expose_php = Off" >> /etc/php5/apache2/php.ini
    sed -i "/track_errors/d" /etc/php5/apache2/php.ini
    echo "track_errors = Off" >> /etc/php5/apache2/php.ini
    sed -i "/html_errors/d" /etc/php5/apache2/php.ini
    echo "html_errors = Off" >> /etc/php5/apache2/php.ini
    sed -i "/display_errors/d" /etc/php5/apache2/php.ini
    echo "display_errors = Off" >> /etc/php5/apache2/php.ini

    #Disables Remote File Includes
    sed -i "/allow_url_fopen/d" /etc/php5/apache2/php.ini
    echo "allow_url_fopen = Off" >> /etc/php5/apache2/php.ini
    sed -i "/allow_url_include/d" /etc/php5/apache2/php.ini
    echo "allow_url_include = Off" >> /etc/php5/apache2/php.ini

    #Restrict File Uploads
    sed -i "/file_uploads/d" /etc/php5/apache2/php.ini
    echo "file_uploads = Off" >> /etc/php5/apache2/php.ini

    #Control POST size
    sed -i '/^post_max_size = 8M/ c\post_max_size = 1K' /etc/php5/apache2/php.ini

    #Protect sessions
    sed -i '/^session.cookie_httponly =/ c\session.cookie_httponly = 1' /etc/php5/apache2/php.ini

    #Disables a metric butt ton of functionality
    echo "disable_functions = php_uname, getmyuid, getmypid, passthru, leak, listen, diskfreespace, tmpfile, link, ignore_user_abord,
    shell_exec, dl, set_time_limit, exec, system, highlight_file, source, show_source, fpaththru, virtual, posix_ctermid, posix_getcwd,
    posix_getegid, posix_geteuid, posix_getgid, posix_getgrgid, posix_getgrnam, posix_getgroups, posix_getlogin, posix_getpgid,
    posix_getpgrp, posix_getpid, posix, _getppid, posix_getpwnam, posix_getpwuid, posix_getrlimit, posix_getsid, posix_getuid, posix_isatty,
    posix_kill, posix_mkfifo, posix_setegid, posix_seteuid, posix_setgid, posix_setpgid, posix_setsid, posix_setuid, posix_times, posix_ttyname,
    posix_uname, proc_open, proc_close, proc_get_status, proc_nice, proc_terminate, phpinfo" >> /etc/php5/apache2/php.ini

    sed -i "/magic_quotes_gpc/d" /etc/php5/apache2/php.ini
    echo "magic_quotes_gpc=Off" >> /etc/php5/apache2/php.ini
    sed -i "/session/d" /etc/php5/apache2/php.ini
    echo "session.cookie_httponly = 1" >> /etc/php5/apache2/php.ini
    sed -i "/expose_php/d" /etc/php5/apache2/php.ini
    echo "expose_php = Off" >> /etc/php5/apache2/php.ini
    sed -i "/session/d" /etc/php5/apache2/php.ini
    echo "session.use_strict_mode = On" >> /etc/php5/apache2/php.ini
    sed -i "/allow_url_fopen/d" /etc/php5/apache2/php.ini
    echo "allow_url_fopen=Off" >> /etc/php5/apache2/php.ini
    sed -i "/allow_url_include/d" /etc/php5/apache2/php.ini
    echo "allow_url_include=Off" >> /etc/php5/apache2/php.ini
    sed -i "/disable_functions/d" /etc/php5/apache2/php.ini
    echo "disable_functions =exec,shell_exec,passthru,system,popen,curl_exec,curl_multi_exec,parse_ini_file,show_source,proc_open,pcntl_exec" >> /etc/php5/apache2/php.ini
    sed -i "/upload_max_filesize/d" /etc/php5/apache2/php.ini
    echo "upload_max_filesize = 2M" >> /etc/php5/apache2/php.ini
    sed -i "/max_execution_time/d" /etc/php5/apache2/php.ini
    echo "max_execution_time = 30" >> /etc/php5/apache2/php.ini
    sed -i "/max_input_time/d" /etc/php5/apache2/php.ini
    echo "max_input_time = 30 " >> /etc/php5/apache2/php.ini
    sed -i "/open_basedir/d" /home/user/public_html"" >> /etc/php5/apache2/php.ini
    echo "open_basedir="/home/user/public_html"" >> /etc/php5/apache2/php.ini
    sed -i "/display_errors/d" /etc/php5/apache2/php.ini
    echo "display_errors = Off" >> /etc/php5/apache2/php.ini
    sed -i "/memory_limit/d" /etc/php5/apache2/php.ini
    echo "memory_limit = 40M" >> /etc/php5/apache2/php.ini
    sed -i "/mail/d" /etc/php5/apache2/php.ini
    echo "mail.add_x_header = Off" >> /etc/php5/apache2/php.ini
    sed -i "/fle_uploads/d" /etc/php5/apache2/php.ini
    echo "fle_uploads=Off" >> /etc/php5/apache2/php.ini
    sed -i "/max_input_time/d" /etc/php5/apache2/php.ini
    echo "max_input_time = 60" >> /etc/php5/apache2/php.ini
    printf "\e[1;34mFinished PHP() function!\e[0m"
    echo ""

    #Enables and configures Suhosin
    apt install php5-suhosin -y
    sed -i "/extension/d" /etc/php5/conf.d/suhosin.ini
    echo "extension=suhosin.so" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.session.encrypt/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.session.encrypt = Off" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.log.syslog/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.log.syslog=511" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.executor.include.max_traversal/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.executor.include.max_traversal=4" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.executor.disable_eval/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.executor.disable_eval=On" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.executor.disable_emodifier/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.executor.disable_emodifier=On" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.mail.protect/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.mail.protect=2" >> /etc/php5/conf.d/suhosin.ini
    sed -i "/suhosin.sql.bailout_on_error/d" /etc/php5/conf.d/suhosin.ini
    echo "suhosin.sql.bailout_on_error=On" >> /etc/php5/conf.d/suhosin.ini

    for file in $(find /etc -iname "php.ini")
    do
      sed -i 's/short_open_tag.*/short_open_tag = Off/g'  $file
      sed -i 's/output_buffering.*/output_buffering = 4096/g'  $file
      sed -i 's/expose_php.*/expose_php = Off/g'  $file
      sed -i 's/display_errors.*/display_errors = Off/g'  $file
      sed -i 's/log_errors.*/log_errors = On/g'  $file
      sed -i 's/enable_dl.*/enable_dl = Off/g'  $file
      sed -i 's/sql.safe_mode.*/sql.safe_mode = On/g'  $file
      sed -i 's/file_uploads.*/file_uploads = On/g'  $file
      sed -i 's/allow_url_fopen.*/allow_url_fopen = Off/g'  $file
      sed -i 's/allow_url_include.*/allow_url_include = Off/g'  $file
      sed -i 's/session.name.*/session.name = COOKIEMONSTER/g'  $file
      sed -i 's/disable_functions.*/disable_functions = pcntl_alarm,pcntl_fork,pcntl_waitpid,pcntl_wait,pcntl_wifexited,pcntl_wifstopped,pcntl_wifsignaled,pcntl_wifcontinued,pcntl_wexitstatus,pcntl_wtermsig,pcntl_wstopsig,pcntl_signal,pcntl_signal_dispatch,pcntl_get_last_error,pcntl_strerror,pcntl_sigprocmask,pcntl_sigwaitinfo,pcntl_sigtimedwait,pcntl_exec,pcntl_getpriority,pcntl_setpriority,exec,passthru,shell_exec,system,proc_open,popen,curl_exec,curl_multi_exec,parse_ini_file,show_source/g'  $file
    done

  fi

}

SSH() {
  if [[ $HasSSH ]]; then

    printf "\033[1;31mRunning SSH()\033[0m\n"
    ufw allow 22

    touch /etc/ssh/sshbackup   
    cp /etc/ssh/sshd_config /etc/ssh/sshbackup
    echo "PermitRootLogin no" > /etc/ssh/sshd_config
    echo "Protocol 2" >> /etc/ssh/sshd_config
    echo "LoginGraceTime 2m" >> /etc/ssh/sshd_config
    echo "IgnoreRhosts yes" >> /etc/ssh/sshd_config
    echo "HostbasedAuthentication no" >> /etc/ssh/sshd_config
    echo "StrictModes yes" >> /etc/ssh/sshd_config
    echo "PasswordAuthentication no" >> /etc/ssh/sshd_config
    echo "PubkeyAuthentication yes" >> /etc/ssh/sshd_config
    echo "ChallengeResponseAuthentication yes" >> /etc/ssh/sshd_config
    echo "PermitEmptyPasswords no" >> /etc/ssh/sshd_config
    echo "Port 22" >> /etc/ssh/sshd_config
    echo "RhostsRSAAuthentication no" >> /etc/ssh/sshd_config
    echo "UsePrivilegeSeparation yes" >> /etc/ssh/sshd_config
    echo "VerifyReverseMapping yes" >> /etc/ssh/sshd_config
    echo "LogLevel VERBOSE" >> /etc/ssh/sshd_config
    echo "AllowTcpForwarding no" >> /etc/ssh/sshd_config
    echo "X11Forwarding no" >> /etc/ssh/sshd_config
    echo "X11UseLocalhost yes" >> /etc/ssh/sshd_config #Configure the SSH server to prevent remote hosts from connecting to the proxy display.
    echo "SyslogFacility AUTH" >> /etc/ssh/sshd_config
    echo "MaxStartups 2" >> /etc/ssh/sshd_config
    echo "PermitUserEnvironment no" >> /etc/ssh/sshd_config
    echo "MaxAuthTries 3" >> /etc/ssh/sshd_config
    echo "UseDNS no" >> /etc/ssh/sshd_config
    echo "PermitTunnel no" >> /etc/ssh/sshd_config
    echo "ClientAliveInterval 300" >> /etc/ssh/sshd_config
    echo "ClientAliveCountMax 1" >> /etc/ssh/sshd_config
    echo "PrintLastLog no" >> /etc/ssh/sshd_config
    echo "GatewayPorts no" >> /etc/ssh/sshd_config
    echo "MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256" >> /etc/ssh/sshd_config
    echo "KexAlgorithms ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256" >> /etc/ssh/sshd_config #use only FIPS-validated key exchange algorithms.
    
    sed -i "s/#Banner none/Banner \/etc\/issue\.net/g" /etc/ssh/sshd_config
    echo "Welcome!" > /etc/issue.net

    #systemctl restart sshd

    #Fixing SSH Host Key Permissions
    find /etc/ssh -maxdepth 1 -type f -name 'ssh_host_*_key' -exec chmod 600 {} \;
    find /etc/ssh -maxdepth 1 -type f -name 'ssh_host_*_key.pub' -exec chmod 644 {} \;
    printf "\e[1;34mFinished SSH() function!\e[0m"
    echo ""

  fi

}

VSFTPD() {
  if [[ $HasVSFTPD ]]; then
    printf "\033[1;31mRunning VSFTPD()\033[0m\n"

    ufw allow 21
    ufw allow 20
    chattr -i /etc/vsftpd.conf
    #ermm what the spruce!?
    sed -i "/anonymous_enable/d" /etc/vsftpd.conf
    echo "anonymous_enable=NO" >> /etc/vsftpd.conf
    sed -i "/chroot_local_user/d" /etc/vsftpd.conf
    echo "chroot_local_user=YES" >> /etc/vsftpd.conf
    sed -i "/anon_world_readable_only/d" /etc/vsftpd.conf
    echo "anon_world_readable_only=YES" >> /etc/vsftpd.conf
    sed -i "/listen_ivp6/d" /etc/vsftpd.conf
    echo "listen_ivp6=NO" >> /etc/vsftpd.conf
    sed -i "/chroot_list_enable/d" /etc/vsftpd.conf
    echo "chroot_list_enable=YES" >> /etc/vsftpd.conf
    sed -i "/passive-promiscuous/d" /etc/vsftpd.conf
    echo "passive-promiscuous=NO" >> /etc/vsftpd.conf
    sed -i "/pasv-enable/d" /etc/vsftpd.conf
    echo "pasv-enable=yes" >> /etc/vsftpd.conf
    sed -i "/port-promiscuous/d" /etc/vsftpd.conf
    echo "port-promiscuous=NO" >> /etc/vsftpd.conf
    sed -i "/port-enable/d" /etc/vsftpd.conf
    echo "port-enable=yes" >> /etc/vsftpd.conf
    sed -i "/hide_ids/d" /etc/vsftpd.conf
    echo "hide_ids=yes" >> /etc/vsftpd.conf
    sed -i "/local_enable/d" /etc/vsftpd.conf
    echo "local_enable=YES" >> /etc/vsftpd.conf
    sed -i "/write_enable/d" /etc/vsftpd.conf
    echo "write_enable=YES" >> /etc/vsftpd.conf
    sed -i "/use_localtime/d" /etc/vsftpd.conf
    echo "use_localtime=YES" >> /etc/vsftpd.conf
    sed -i "/dirmessage_enable/d" /etc/vsftpd.conf
    echo "dirmessage_enable=YES" >> /etc/vsftpd.conf
    sed -i "/xferlog_enable/d" /etc/vsftpd.conf
    echo "xferlog_enable=YES" >> /etc/vsftpd.conf
    sed -i "/connect_from_port_20/d" /etc/vsftpd.conf
    echo "connect_from_port_20=YES" >> /etc/vsftpd.conf
    sed -i "/ascii_upload_enable/d" /etc/vsftpd.conf
    echo "ascii_upload_enable=NO" >> /etc/vsftpd.conf
    sed -i "/ascii_download_enable/d" /etc/vsftpd.conf
    echo "ascii_download_enable=NO" >> /etc/vsftpd.conf
    sed -i "/anon_upload_enable/d" /etc/vsftpd.conf
    echo "anon_upload_enable=NO" >> /etc/vsftpd.conf
    sed -i "/anon_mkdir_write_enable/d" /etc/vsftpd.conf
    echo "anon_mkdir_write_enable=NO" >> /etc/vsftpd.conf
    sed -i "/ssl_enable/d" /etc/vsftpd.conf
    echo "ssl_enable=YES" >> /etc/vsftpd.conf
    sed -i "/ssl_sslv3/d" /etc/vsftpd.conf
    echo "ssl_sslv3=NO" >> /etc/vsftpd.conf
    sed -i "/ssl_tlsv1/d" /etc/vsftpd.conf
    echo "ssl_tlsv1=YES" >> /etc/vsftpd.conf
    sed -i "/allow_anon_ssl/d" /etc/vsftpd.conf
    echo "allow_anon_ssl=NO" >> /etc/vsftpd.conf
    sed -i "/ssl_ciphers/d" /etc/vsftpd.conf
    echo "ssl_ciphers=HIGH" >> /etc/vsftpd.conf
    sed -i "/max_per_ip/d" /etc/vsftpd.conf
    echo "max_per_ip=5" >> /etc/vsftpd.conf
    sed -i "/listen_ipv6=YES/d" /etc/vsftpd.conf
    echo "listen_ipv6=NO" >> /etc/vsftpd.conf
    sed -i "/allow_writeable_chroot/d" /etc/vsftpd.conf
    echo "allow_writeable_chroot=YES" >> /etc/vsftpd.conf
    sed -i "/max_login_fails/d" /etc/vsftpd.conf
    echo "max_login_fails=3" >> /etc/vsftpd.conf
    sed -i "/delay_failed_login/d" /etc/vsftpd.conf
    echo "delay_failed_login=5" >> /etc/vsftpd.conf
    sed -i "/local_umask/d" /etc/vsftpd.conf
    echo "local_umask=022" >> /etc/vsftpd.conf
    sed -i "/pasv_enable/d" /etc/vsftpd.conf
    echo "pasv_enable=YES" >> /etc/vsftpd.conf
    sed -i "/pasv_min_port/d" /etc/vsftpd.conf
    echo "pasv_min_port=40000" >> /etc/vsftpd.conf
    sed -i "/pasv_max_port/d" /etc/vsftpd.conf
    echo "pasv_max_port=40100" >> /etc/vsftpd.conf
    sed -i "/dual_log_enable/d" /etc/vsftpd.conf
    echo "dual_log_enable=YES" >> /etc/vsftpd.conf
    sed -i "/log_ftp_protocol/d" /etc/vsftpd.conf
    echo "log_ftp_protocol=YES" >> /etc/vsftpd.conf
    sed -i "/xferlog_std_format/d" /etc/vsftpd.conf
    echo "xferlog_std_format=YES" >> /etc/vsftpd.conf
    sed -i "/force_local_data_ssl/d" /etc/vsftpd.conf
    echo "force_local_data_ssl=YES" >> /etc/vsftpd.conf
    sed -i "/force_local_logins_ssl/d" /etc/vsftpd.conf
    echo "force_local_logins_ssl=YES" >> /etc/vsftpd.conf
    sed -i "/require_ssl_reuse/d" /etc/vsftpd.conf
    echo "require_ssl_reuse=YES" >> /etc/vsftpd.conf
    sed -i "/no_anon_password/d" /etc/vsftpd.conf
    echo "no_anon_password=NO" >> /etc/vsftpd.conf
    sed -i "/idle_session_timeout/d" /etc/vsftpd.conf
    echo "idle_session_timeout=300" >> /etc/vsftpd.conf
    sed -i "/data_connection_timeout/d" /etc/vsftpd.conf
    echo "data_connection_timeout=120" >> /etc/vsftpd.conf
    sed -i "/hide_ids/d" /etc/vsftpd.conf
    echo "hide_ids=YES" >> /etc/vsftpd.conf
    sed -i "/nopriv_user/d" /etc/vsftpd.conf
    echo "nopriv_user=nobody" >> /etc/vsftpd.conf
    sed -i "/ls_recurse_enable/d" /etc/vsftpd.conf
    echo "ls_recurse_enable=NO" >> /etc/vsftpd.conf

# example conf
# Jail users to home directory (user will need a home dir to exist)
#chroot_local_user=YES
#chroot_list_enable=YES
#chroot_list_file=/etc/vsftpd.chroot_list
#allow_writeable_chroot=YES # Only enable if you want files to be editable
# Allow or deny users
#userlist_enable=YES
#userlist_file=/etc/vsftpd.userlist
#userlist_deny=NO
# General config
#anonymous_enable=NO # disable anonymous login
#ocal_enable=YES # permit local logins
#write_enable=YES # enable FTP commands which change the filesystem
#local_umask=022 # value of umask for file creation for local users
#dirmessage_enable=YES # enable showing of messages when users first enter a
#new directory
#xferlog_enable=YES # a log file will be maintained detailing uploads and
#downloads
#connect_from_port_20=YES # use port 20 (ftp-data) on the server machine for PORT
#style connections
#xferlog_std_format=YES # keep standard log file format
#listen=NO # prevent vsftpd from running in standalone mode
#listen_ipv6=YES # vsftpd will listen on an IPv6 socket instead of an
#IPv4 one
#pam_service_name=vsftpd # name of the PAM service vsftpd will use
#userlist_enable=YES # enable vsftpd to load a list of usernames
#tcp_wrappers=YES # turn on tcp wrappers

    printf "\e[1;34mFinished VSFTPD() function!\e[0m"
    echo ""
  fi
}

PureFTPD() {
  if [[ $HasPureFTPD ]]; then

    printf "\e[1;34mRunning PureFTPD()\e[0m"
    chattr -i /etc/pure-ftpd/conf
    echo "yes" >> /etc/pure-ftpd/conf/NoAnonymous
    echo "yes" >> /etc/pure-ftpd/conf/ChrootEveryone
    echo "yes" >> /etc/pure-ftpd/conf/IPV4Only
    echo "yes" >> /etc/pure-ftpd/conf/ProhibitDotFilesWrite
    echo "2" > /etc/pure-ftpd/conf/TLS
    echo 2 |  tee /etc/pure-ftpd/conf/TLS
    echo 1 |  tee /etc/pure-ftpd/conf/NoAnonymous

    printf "\e[1;34mFinished PureFTPD() function!\e[0m"
  fi

}

ProFTP() {
  if [[ $HasProFTP ]]; then

    printf "\e[1;34mRunning ProFTP()\e[0m"
    sed -i "/DelayEngine/d" /etc/proftpd/proftpd.conf
    echo "DelayEngine on" >> /etc/proftpd/proftpd.conf
    sed -i "/UseLastLog/d" /etc/proftpd/proftpd.conf
    echo "UseLastLog on" >> /etc/proftpd/proftpd.conf
    sed -i "/ServerIndent/d" /etc/proftpd/proftpd.conf
    echo "ServerIndent Off" >> /etc/proftpd/proftpd.conf
    sed -i "/IdentLookups/d" /etc/proftpd/proftpd.conf
    echo "IdentLookups off" >> /etc/proftpd/proftpd.conf
    sed -i "/TLSEngine/d" /etc/proftpd/proftpd.conf
    echo "TLSEngine on" >> /etc/proftpd/proftpd.conf
    sed -i "/TLSProtocol/d" /etc/proftpd/proftpd.conf
    echo "TLSProtocol SSLv23" >> /etc/proftpd/proftpd.conf
    sed -i "/TLSRequired/d" /etc/proftpd/proftpd.conf
    echo "TLSRequired On" >> /etc/proftpd/proftpd.conf
    sed -i "/UseReverseDNS/d" /etc/proftpd/proftpd.conf
    echo "UseReverseDNS On" >> /etc/proftpd/proftpd.conf
    printf "\e[1;34mFinished ProFTP() function!\e[0m"
  fi

}

File(){

  printf "\033[1;31mSetting file permissions...\033[0m\n"

  echo "exit 0" > /etc/rc.local
  touch /etc/security/opasswd

  chown root:root /etc/fstab
  chmod 644 /etc/fstab
  chown root:root /etc/group
  chmod 644 /etc/group
  chmod 640 /etc/shadow
  chown root:root /etc/apache2
  chmod 755 /etc/apache2
  chmod 0600 /etc/securetty
  chmod 644 /etc/crontab
  chmod 640 /etc/ftpusers
  chmod 440 /etc/inetd.conf
  chmod 440 /etc/xinetd.conf
  chmod 400 /etc/inetd.d
  chmod 644 /etc/hosts.allow
  chmod 440 /etc/ers
  chmod 600 /boot/grub/grub.cfg
  chmod 600 /etc/ssh/sshd_config
  chmod 600 /etc/gshadow-
  chmod 600 /etc/group-
  chmod 600 /etc/passwd-
  chmod 600 /etc/security/opasswd
  chown root:root /etc/ssh/sshd_config
  chown root:root /etc/passwd-
  chown root:root /etc/group-
  chown root:shadow /etc/shadow
  chown root:root /etc/securetty
  chown root:root /boot/grub/grub.cfg
  chmod og-rwx /boot/grub/grub.cfg
  chown root:shadow /etc/shadow-
  chmod o-rwx,g-rw /etc/shadow-
  chown root:shadow /etc/gshadow-
  chmod o-rwx,g-rw /etc/gshadow-
  touch /etc/cron.allow
  touch /etc/at.allow
  chmod og-rwx /etc/cron.allow
  chmod og-rwx /etc/at.allow
  chown root:root /etc/cron.allow
  chown root:root /etc/at.allow
  chown root:root /etc/cron.d
  chmod og-rwx /etc/cron.d
  chown root:root /etc/crontab
  chmod og-rwx /etc/crontab
  chmod -R g-wx,o-rwx /var/log/
  chmod 755 /etc/resolvconf/resolv.conf.d/
  chmod 600 /swapfile
  chmod 644 /etc/resolvconf/resolv.conf.d/base
  chmod 740 /usr/bin/journalctl #its a stig lol
  chmod 777 /etc/resolv.conf
  chmod 644 /etc/hosts
  chmod 644 /etc/host.conf
  chmod 644 /etc/hosts.deny
  chmod 755 /etc/apt/
  chmod 755 /etc/apt/apt.conf.d/
  chmod 644 /etc/apt/apt.conf.d/10periodic
  chmod 644 /etc/apt/apt.conf.d/20auto-upgrades
  chmod 664 /etc/apt/sources.list
  chmod 644 /etc/default/ufw
  chmod 755 /etc/ufw/
  chmod 644 /etc/ufw/sysctl.conf
  chmod 755 /etc/sysctl.d/
  chmod 644 /etc/sysctl.conf
  chmod 644 /proc/sys/net/ipv4/ip_forward
  chmod 644 /etc/passwd
  chmod 640 /etc/shadow
  chmod 644 /etc/group
  chmod 640 /etc/gshadow
  chmod 755 /etc/sudoers.d/
  chmod 440 /etc/sudoers.d/*
  chmod 440 /etc/sudoers
  chmod 644 /etc/deluser.conf
  chmod 644 /etc/adduser.conf
  chmod 644 /etc/login.defs
  chmod 644 /etc/pam.d/common-auth
  chmod 644 /etc/pam.d/common-password
  chmod 755 /etc/rc.local
  chmod 755 /etc/grub.d/
  chmod 600 /etc/securetty
  chmod 644 /etc/security/limits.conf
  chmod 664 /etc/fstab
  chmod 644 /etc/updatedb.conf
  chmod 644 /etc/modprobe.d/blacklist.conf
  chmod 644 /etc/environment
  chmod 600 /boot/grub2/grub.cfg
  chmod 600 /boot/grub.d/*
  chmod 600 /etc/default/grub
  chmod 755 /etc
  chmod 755 /bin
  chmod 755 /boot
  chmod 775 /cdrom
  chmod 755 /dev
  chmod 755 /home
  chmod 755 /lib
  chmod 755 /media
  chmod 755 /mnt
  chmod 755 /opt
  chmod 555 /proc/
  chmod 700 /root
  chmod 755 /run
  chmod 755 /sbin
  chmod 755 /snap
  chmod 755 /srv
  chmod 555 /sys
  chmod 1777 /tmp
  chmod 1777 /var/tmp
  chmod 755 /usr
  chmod 755 /var/
  chown root:root /etc/resolvconf/resolv.conf.d/
  chown root:root /etc/resolvconf/resolv.conf.d/base
  chown root:root /etc/resolv.conf
  chown root:root /etc/hosts
  chown root:root /etc/host.conf
  chown root:root /etc/hosts.deny
  chown root:root /etc/apt/
  chown root:root /etc/apt/apt.conf.d/
  chown root:root /etc/apt/apt.conf.d/10periodic
  chown root:root /etc/apt/apt.conf.d/20auto-upgrades
  chown root:root /etc/apt/sources.list
  chown root:root /etc/default/ufw
  chown root:root /etc/ufw/
  chown root:root /etc/ufw/sysctl.conf
  chown root:root /etc/sysctl.d/
  chown root:root /etc/sysctl.conf
  chown root:root /proc/sys/net/ipv4/ip_forward
  chown root:root /etc/passwd
  chown root:shadow /etc/shadow
  chown root:root /etc/group
  chown root:shadow /etc/gshadow
  chown root:root /etc/sudoers.d/
  chown root:root /etc/sudoers.d/*
  chown root:root /etc/sudoers
  chown root:root /etc/deluser.conf
  chown root:root /etc/adduser.conf
  chown root:root /etc/login.defs
  chown root:root /etc/pam.d/common-auth
  chown root:root /etc/pam.d/common-password
  chown root:root /etc/rc.local
  chown root:root /etc/grub.d/
  chown root:root /etc/securetty
  chown root:root /etc/security/limits.conf
  chown root:root /etc/fstab
  chown root:root /etc/updatedb.conf
  chown root:root /etc/modprobe.d/blacklist.conf
  chown root:root /etc/environment
  chown root:root /boot/grub2/grub.cfg
  chown root:root /etc
  chown root:root /bin
  chown root:root /boot
  chown root:root /cdrom
  chown root:root /dev
  chown root:root /home
  chown root:root /lib
  chown root:root /media
  chown root:root /mnt
  chown root:root /opt
  chown root:root /proc/
  chown root:root /root
  chown root:root /run
  chown root:root /sbin
  chown root:root /snap
  chown root:root /srv
  chown root:root /sys
  chown root:root /tmp
  chown root:root /usr
  chown root:root /var/
  chgrp adm /var/log/syslog
  chgrp syslog /var/log
  chmod 0640 /var/log/syslog
  chown root /var/log
  chmod 0755 /var/log
  chown root:root /usr/bin/journalctl
  chown root /usr/bin/journalctl
  find /lib /usr/lib /lib64 ! -group root -type d -exec chgrp root '{}' \;
  chmod 755 /sbin/auditctl 
  chmod 755 /sbin/aureport 
  chmod 755 /sbin/ausearch 
  chmod 755 /sbin/autrace 
  chmod 755 /sbin/auditd 
  chmod 755 /sbin/audispd-zos-remote 
  chmod 755 /sbin/augenrules 
  chmod 2750 /run/log/journal
  chmod 2750 /var/log/journal
  find /var/log -perm /137 ! -name '*[bw]tmp' ! -name '*lastlog' -type f -exec chmod 640 '{}' \;
  find /lib /lib64 /usr/lib -perm /022 -type f -exec chmod 755 '{}' \;
  find /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -perm /022 -type f -exec chmod 755 '{}' \;
  find /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin -perm /022 -type d -exec chmod -R 755 '{}' \;
  
  printf "\e[1;34mFinished File() function!\e[0m"
}

Misc(){
  printf "\033[1;31mRunning Misc()\033[0m\n"

  #Disable automounting
  systemctl disable autofs
  service autofs stop

  # set users umask
  sed -i "s/UMASK.*022/UMASK   077/" /etc/login.defs

  # set root umask
  sed -i "s/#.*umask.*022/umask 077/" /root/.bashrc

  #Restricts umask
  sed -i s/umask\ 022/umask\ 027/g /etc/init.d/rc

  #Set all apparmor profiles to enforce mode
  systemctl enable apparmor
  systemctl start apparmor
  aa-enforce /etc/apparmor.d/*

  #Disables ctrl-alt-delete
  systemctl mask ctrl-alt-del.target
  systemctl daemon-reload

  #Disable UFW ipv6
  sed -i 's/^IPV6=yes/IPV6=no/' /etc/default/ufw
  
  #Disables cups
  systemctl disable cups
  systemctl disable cupsd

  #FREE POINTS FREE POINTS FREE POINTS FREE POINTS FREE POINTS FREE POINTS FREE POINTS 
  ufw enable
  ufw logging high
  ufw default deny incoming

  sed -i "/noexec/d" /etc/default/grub
  echo "noexec=on" >> /etc/default/grub
  sed -i '/^GRUB_CMDLINE_LINUX=/ s/"$/ audit=1"/' /etc/default/grub # enables auditing at system startup in grub

  # Make a backup of the original file
  cp /etc/ufw/before.rules /etc/ufw/before.rules.bak

  #replace 'ACCEPT' with 'DROP' for icmp rules
  sed -i 's/-A ufw-before-input -p icmp --icmp-type\(.*\)-j ACCEPT/-A ufw-before-input -p icmp --icmp-type\1-j DROP/g' /etc/ufw/before.rules

  # Reload UFW to apply changes
  ufw reload

  echo "UFW rules updated to DROP ICMP packets"

  echo "Storage=none" >> /etc/systemd/coredump.conf
  echo "Storage=none" >> /etc/systemd/system.conf
  echo "ProcessSizeMax=0" >> /etc/systemd/system.conf
  echo "DumpCore=no" >> /etc/systemd/system.conf
  ulimit -c 0

  #Hardening /proc with hidepid
  mount -o remount,rw,hidepid=2 /proc

  #Applying apparmor to Firefox and applying settings
  aa-enforce /etc/apparmor.d/usr.bin.Firefox

  #Secure sudoers
  sed -i 's/NOPASSWD://g' /etc/sudoers
  sed -i 's/!authenticate//g' /etc/sudoers
  echo "Defaults        env_reset" >> /etc/sudoers

  
  #DNS
  sed -i "/LLMNR/d" /etc/systemd/resolved.conf
  echo "LLMNR=no" >> /etc/systemd/resolved.conf
  sed -i "/DNSSEC/d" /etc/systemd/resolved.conf
  echo "DNSSEC=yes" >> /etc/systemd/resolved.conf
  sed -i "/DNSOverTLS/d" /etc/systemd/resolved.conf
  echo "DNSOverTLS=yes" >> /etc/systemd/resolved.conf
  sed -i "/Cache=/d" /etc/systemd/resolved.conf
  echo "Cache=no-negative" >> /etc/systemd/resolved.conf
  sed -i "/MulticastDNS/d" /etc/systemd/resolved.conf
  echo "MulticastDNS=no" >> /etc/systemd/resolved.conf
  sed -i "/DNSStubListener/d" /etc/systemd/resolved.conf
  echo "DNSStubListener=no" >> /etc/systemd/resolved.conf

  echo "offline_credentials_expiration = 1" >> /etc/sssd/sssd.conf

  systemctl mask kdump-tools --now

  #Secured shared memory TODO: this is sketchy and breaks things!!! do not run 
  echo "none     /run/shm    tmpfs    ro,noexec,nosuid,nodev,defaults    0    0" >> /etc/fstab
  echo "tmpfs /run/shm tmpfs defaults,nodev,noexec,nosuid 0 0" >> /etc/fstab
  echo "tmpfs /tmp tmpfs defaults,rw,nosuid,nodev,noexec,relatime 0 0" >> /etc/fstab
  echo "tmpfs /var/tmp tmpfs defaults,nodev,noexec,nosuid 0 0" >> /etc/fstab
  echo "proc /proc proc nosuid,nodev,noexec,hidepid=2,gid=proc 0 0" >> /etc/fstab
  echo "LABEL=/boot /boot ext2 defaults,ro 1 2" >> /etc/fstab
  
  echo "blacklist usb-storage" >> /etc/modprobe.d/blacklist.conf
  echo "blacklist thunderbolt" >> /etc/modprobe.d/thunderbolt.conf
  echo "install usb-storage /bin/true" >> /etc/modprobe.d/disable-usb-storage.conf
  echo "install usb-storage /bin/false" >> /etc/modprobe.d/usb-storage.conf

  #Changes the nameserver to 8.8.8.8, Google's DNS.
  #echo "nameserver 8.8.8.8 " >> /etc/resolv.conf

  chown root:root /etc/motd
  chmod 644 /etc/motd
  echo "Authorized uses only. All activity may be monitored and reported." > /etc/motd

  chown root:root /etc/issue
  chmod 644 /etc/issue
  echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue

  chown root:root /etc/issue.net
  chmod 644 /etc/issue.net
  echo "Authorized uses only. All activity may be monitored and reported." > /etc/issue.net

  # Find and secure SUID binaries while preserving essential system binaries
  SUID_WHITELIST="/bin/su|sudo|/usr/bin/passwd"
  find / -perm /4000 -type f ! -regex "$SUID_WHITELIST" -exec chmod -s {} \; 2>/dev/null
  chmod +s $(which sudo)

  # Configure journald for persistent storage
  sed -i 's/^#*Storage=.*/Storage=persistent/' /etc/systemd/journald.conf
  mkdir -p /var/log/journal && chmod 2755 /var/log/journal && systemd-tmpfiles --create --prefix /var/log/journal
  #systemctl restart systemd-journald

  printf "\e[1;34mFinished Misc() function!\e[0m"
}

Sysctl(){

  printf "\033[1;31mAppyling Sysctl hardening...\033[0m\n"
  #--------- Secure /etc/sysctl.conf ----------------
  cp /etc/sysctl.conf /etc/sysctl.conf.bak
  echo "net.ipv4.tcp_syncookies=1
kernel.dmesg_restrict=1
net.ipv4.tcp_max_syn_backlog=2048
net.ipv4.tcp_synack_retries=2
net.ipv4.tcp_syn_retries=5
net.ipv4.ip_forward=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.default.send_redirects=0
net.ipv4.conf.all.accept_redirects=0
net.ipv4.conf.default.accept_redirects=0
net.ipv4.conf.all.secure_redirects=0
net.ipv4.conf.default.secure_redirects=0
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.conf.all.accept_source_route=0
net.ipv6.conf.all.accept_source_route=0
net.ipv4.conf.default.accept_source_route=0
net.ipv6.conf.default.accept_source_route=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.all.log_martians=1
net.ipv4.icmp_ignore_bogus_error_responses=1
net.ipv6.conf.default.accept_redirects=0
net.ipv6.conf.all.accept_redirects=0
fs.suid_dumpable=0
kernel.msgmnb=65536
kernel.msgmax=65536
kernel.sysrq=0
kernel.maps_protect=1
kernel.core_uses_pid=1
kernel.shmmax=68719476736
kernel.shmall=4294967296
net.ipv6.conf.all.accept_redirects=0
net.ipv4.icmp_echo_ignore_all=1
kernel.exec-shield=1
kernel.panic=10
kernel.kptr_restrict=2
vm.panic_on_oom=1
fs.protected_hardlinks=1
fs.protected_symlinks=1
fs.protected_regular=1
fs.protected_fifos=1
kernel.randomize_va_space=2
net.ipv6.conf.default.router_solicitations=0
net.ipv6.conf.default.accept_ra_rtr_pref=0
net.ipv6.conf.default.accept_ra_pinfo=0
net.ipv6.conf.default.accept_ra_defrtr=0
net.ipv6.conf.default.autoconf=0
net.ipv6.conf.default.dad_transmits=0
net.ipv6.conf.default.max_addresses=1
net.ipv6.conf.all.use_tempaddr = 2
net.ipv6.conf.default.use_tempaddr = 2
net.ipv4.tcp_rfc1337=1
kernel.unprivileged_userns_clone=0
kernel.unprivileged_bpf_disabled=2
kernel.perf_event_paranoid=3
kernel.ctrl-alt-del=1
net.ipv6.conf.all.disable_ipv6=1
net.ipv6.conf.lo.disable_ipv6=1
net.ipv6.conf.default.disable_ipv6 = 1
kernel.kexec_load_disabled=1
kernel.yama.ptrace_scope=2
net.ipv4.tcp_timestamps=0
net.ipv4.tcp_sack=0
net.ipv4.tcp_dsack=0
net.ipv4.tcp_fack=0
net.core.bpf_jit_harden=2
vm.mmap_rnd_bits=32
vm.mmap_rnd_compat_bits=16
vm.mmap_min_addr=65536
  " > /etc/sysctl.conf
#meow meow meow 
  sysctl -p

  printf "\e[1;34mFinished Sysctl() function!\e[0m"
}

Auditctl() { #This is most likely useless.
  
  printf "\e[1;34mRunning Auditctl()\e[0m"
  echo "
  # First rule - delete all
  -D

  #Ensure events that modify date and time information are collected

  -a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
  -a always,exit -F arch=b64 -S clock_settime -k time-change
  -a always,exit -F arch=b32 -S clock_settime -k time-change
  -w /etc/localtime -p wa -k time-change

  #Ensure events that modify user/group information are collected

  -w /etc/group -p wa -k identity
  -w /etc/passwd -p wa -k identity
  -w /etc/gshadow -p wa -k identity
  -w /etc/shadow -p wa -k identity
  -w /etc/security/opasswd -p wa -k identity

  #Ensure events that modify the system's network environment are collected

  -a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale
  -a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale
  -w /etc/issue -p wa -k system-locale
  -w /etc/issue.net -p wa -k system-locale
  -w /etc/hosts -p wa -k system-locale
  -w /etc/network -p wa -k system-locale
  -w /etc/networks -p wa -k system-locale

  #Ensure events that modify system's MAC are collected

  -w /etc/apparmor/ -p wa -k MAC-policy
  -w /etc/apparmor.d/ -p wa -k MAC-policy

  #Ensure login and logouts events are collected

  -w /var/log/faillog -p wa -k logins
  -w /var/log/lastlog -p wa -k logins
  -w /var/log/tallylog -p wa -k logins

  #Ensure session initiation information is collected

  -w /var/run/utmp -p wa -k session
  -w /var/run/wtmp -p wa -k session
  -w /var/run/btmp -p wa -k session

  #Ensure discretionary access control permission modification events are collected

  -a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
  -a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
  -a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
  -a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
  -a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
  -a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod

  #Ensure unsuccessful unauthorized file access attempts are collected

  -a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
  -a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
  -a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access
  -a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access

  #Ensure successful file system mounts are collected

  -a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts
  -a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts

  #Ensure file deletion events by users are collected

  -a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete
  -a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete

  #Ensure changes to system administration scope (ers) is collected

  -w /etc/ers -p wa -k scope
  -w /etc/ers.d -p wa -k scope

  #Ensure system administrator actions (log) are collected

  -w /var/log/.log -p wa -k actions

  #Ensure kernel module loading and unloading is collected

  -w /sbin/insmod -p x -k modules
  -w /sbin/rmmod -p x -k modules
  -w /sbin/modprobe -p x -k modules
  -a always,exit -F arch=b64 -S init_module -S delete_module -k modules

  # increase the buffers to survive stress events. make this bigger for busy systems.
  -b 1024

  # monitor unlink() and rmdir() system calls.
  -a exit,always -S unlink -S rmdir

  # monitor open() system call by Linux UID 1001.
  -a exit,always -S open -F loginuid=1001

  " >> /etc/audit/audit.rules

  sed -i "/local_events/d" /etc/audit/auditd.conf
  echo "local_events = yes" >> /etc/audit/auditd.conf
  
  printf "\e[1;34mFinished Auditctl() function!\e[0m"
}

apt autoremove -y

Main 
