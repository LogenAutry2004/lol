#!/bin/bash

# Function to handle package management
function PackageManagement() {
    printf "Configuring package management...\n"

    # Create directories for audit files
    mkdir -p /home/files

    # Export package lists and system info
    echo "Gathering system information..."
    rpm -qa >> /home/files/allpackages.txt
    ps aux >> /home/files/rootprocesses.txt
    systemctl list-units --type=service >> /home/files/services.txt
    ss -tulpn >> /home/files/networkscan.txt

    # Update system
    dnf update -y
    dnf upgrade -y

    printf "\e[1;34mStarting package management!\e[0m\n"

    # Install necessary security packages
    dnf install -y \
        gedit \
        sudo \
        clamav \
        clamav-update \
        firewalld \
        htop \
        iptables \
        iptables-services \
        audit \
        openssh-server \
        apparmor \
        apparmor-utils \
        ranger \
        dnf-automatic \
        cracklib \
        cracklib-dicts \
        pam_pwquality \
        grub2-tools \
        git \
        mlocate \
        lynis \
        chkrootkit \
        terminator \
        unhide \
        rkhunter \
        fail2ban

    # Download additional security tools
    wget https://github.com/DominicBreuker/pspy/releases/download/v1.2.1/pspy64
    wget https://github.com/peass-ng/PEASS-ng/releases/latest/download/linpeas.sh

    chmod +x pspy64
    chmod +x linpeas.sh

    # Remove potentially dangerous packages
    dnf remove -y \
        gcc \
        john \
        sqlmap \
        nmap \
        wireshark \
        telnet \
        telnet-server \
        bind \
        vsftpd \
        ftp \
        xinetd \
        rsh-server \
        rsh \
        talk-server \
        talk \
        tftp-server \
        tftp \
        ypserv \
        ypbind \
        rpcbind \
        postfix \
        dovecot \
        cyrus-imapd \
        sendmail \
        dhcp-server \
        dhcp-client \
        tomcat \
        httpd \
        nginx \
        mariadb-server \
        postgresql-server \
        cups \
        samba \
        nfs-utils \
        wesnoth \
        steam \
        wine \
        transmission \
        deluge \
        qbittorrent

    # Configure automatic updates for dnf
    echo "[commands]
upgrade_type = security
download_updates = yes
apply_updates = yes" > /etc/dnf/automatic.conf

    systemctl enable --now dnf-automatic.timer

    # Run security scans
    printf "\e[1;34mRunning security scans...\e[0m\n"
    chkrootkit >> /home/files/chkrootkit.txt
    rkhunter --update
    rkhunter -c --skip-keypress >> /home/files/rkhunter.txt

    # Find suspicious files
    find -L /bin /sbin /usr/bin /usr/sbin /usr/local/bin /usr/local/sbin ! -group root -type f ! -perm /2000 -exec stat -c "%n %G" '{}' \; > /home/files/suspicious_files.txt

    # Search for various file types (keeping the same file search logic as original)
    for ext in txt xlsx csv doc docx pdf rtf ppt pptx jpg jpeg png mp3 mp4 wav avi mov py sh php pl cgi exe bat dll; do
        find / -name "*.${ext}" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > "/home/files/${ext}_files.txt"
    done

    # Search for suspicious names
    find / -name "*backdoor*" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/files/backdoor_files.txt
    find / -name "*rootkit*" -type f -not -path "/proc/*" -not -path "/sys/*" -not -path "/run/*" 2>/dev/null | sort -u > /home/files/rootkit_files.txt

    # Clean up
    dnf clean all
    dnf autoremove -y

    printf "\e[1;34mFinished PackageManagement function!\e[0m\n"
}

# Function for audit configuration
function ConfigureAudit() {
    printf "\e[1;34mConfiguring audit rules...\e[0m\n"

    # Configure auditd
    cat > /etc/audit/auditd.conf << EOF
log_file = /var/log/audit/audit.log
log_format = RAW
log_group = root
priority_boost = 4
flush = INCREMENTAL_ASYNC
freq = 50
num_logs = 5
disp_qos = lossy
dispatcher = /sbin/audispd
name_format = NONE
max_log_file = 8
max_log_file_action = ROTATE
space_left = 75
space_left_action = SYSLOG
admin_space_left = 50
admin_space_left_action = SUSPEND
disk_full_action = SUSPEND
disk_error_action = SUSPEND
use_libwrap = yes
tcp_listen_queue = 5
tcp_max_per_addr = 1
tcp_client_max_idle = 0
enable_krb5 = no
krb5_principal = auditd
distribute_network = no
EOF

    # Configure audit rules
    cat > /etc/audit/rules.d/audit.rules << EOF
# Delete all existing rules
-D

# Set buffer size
-b 8192

# Monitor file system mounts
-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts

# Monitor changes to system administration scope
-w /etc/sudoers -p wa -k scope
-w /etc/sudoers.d/ -p wa -k scope

# Monitor system authentication
-w /etc/pam.d/ -p wa -k pam
-w /etc/security/ -p wa -k security
-w /etc/passwd -p wa -k identity
-w /etc/shadow -p wa -k identity
-w /etc/group -p wa -k identity
-w /etc/gshadow -p wa -k identity

# Monitor important command execution
-a always,exit -F path=/usr/bin/sudo -F perm=x -F auid>=1000 -F auid!=4294967295 -k sudo_log
-a always,exit -F path=/usr/bin/su -F perm=x -F auid>=1000 -F auid!=4294967295 -k su_log

# Monitor system calls
-a exit,always -F arch=b64 -S unlink -S rmdir
-a exit,always -F arch=b64 -S chmod -S fchmod -S chown -S fchown
-a exit,always -F arch=b64 -S creat -S open -S openat -F exit=-EACCES
-a exit,always -F arch=b64 -S creat -S open -S openat -F exit=-EPERM
EOF

    # Restart audit daemon
    service auditd restart

    printf "\e[1;34mFinished ConfigureAudit function!\e[0m\n"
}

# Main execution
PackageManagement
ConfigureAudit

printf "\e[1;32mScript completed successfully!\e[0m\n"